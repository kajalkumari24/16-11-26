/**
 * Color manipulation, WCAG contrast verification, and formatting utilities
 */

export function rgbToHex(r, g, b) {
  const clamp = (val) => Math.max(0, Math.min(255, Math.round(val)));
  return (
    '#' +
    [r, g, b]
      .map((x) => clamp(x).toString(16).padStart(2, '0'))
      .join('')
  );
}

export function hexToRgb(hex) {
  let clean = hex.replace('#', '');
  if (clean.length === 3) {
    clean = clean.split('').map((c) => c + c).join('');
  }
  const num = parseInt(clean, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255
  };
}

/**
 * Calculates relative luminance according to WCAG 2.1 specs
 */
export function getLuminance(r, g, b) {
  const a = [r, g, b].map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
}

/**
 * Returns either '#FFFFFF' or '#0F172A' depending on which has higher contrast
 */
export function getContrastTextColor(hexBg) {
  const { r, g, b } = hexToRgb(hexBg);
  const lum = getLuminance(r, g, b);
  // If background luminance is below 0.45, white text is chosen; otherwise dark text
  return lum < 0.45 ? '#FFFFFF' : '#0F172A';
}

/**
 * Calculates Euclidean distance between two colors
 */
export function getColorDistance(rgb1, rgb2) {
  const dr = rgb1.r - rgb2.r;
  const dg = rgb1.g - rgb2.g;
  const db = rgb1.b - rgb2.b;
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

/**
 * Generates an accent color by shifting hue or brightness
 */
export function shiftBrightness(hex, percent) {
  const { r, g, b } = hexToRgb(hex);
  const factor = 1 + percent / 100;
  return rgbToHex(
    Math.min(255, Math.max(0, r * factor)),
    Math.min(255, Math.max(0, g * factor)),
    Math.min(255, Math.max(0, b * factor))
  );
}

