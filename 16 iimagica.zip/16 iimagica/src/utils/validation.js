/**
 * Validation utilities for file uploads and image safety
 */

export const MAX_FILE_SIZE_BYTES = 15 * 1024 * 1024; // 15 MB
export const SUPPORTED_MIME_TYPES = [
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp'
];

export const SUPPORTED_EXTENSIONS = ['png', 'jpg', 'jpeg', 'webp'];

/**
 * Validates an uploaded image file
 * @param {File} file
 * @returns {{ valid: boolean, error?: string }}
 */
export function validateImageFile(file) {
  if (!file) {
    return { valid: false, error: 'No file selected.' };
  }

  // Check MIME type
  if (!SUPPORTED_MIME_TYPES.includes(file.type.toLowerCase())) {
    const ext = file.name.split('.').pop().toLowerCase();
    if (!SUPPORTED_EXTENSIONS.includes(ext)) {
      return {
        valid: false,
        error: `Unsupported format ".${ext}". Please upload PNG, JPG, JPEG, or WebP.`
      };
    }
  }

  // Check file size
  if (file.size > MAX_FILE_SIZE_BYTES) {
    const sizeMb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      error: `File is too large (${sizeMb} MB). Maximum allowed size is 15 MB.`
    };
  }

  return { valid: true };
}

