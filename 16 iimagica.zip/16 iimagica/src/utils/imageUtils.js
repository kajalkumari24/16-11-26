/**
 * Image processing and Canvas helpers
 */

/**
 * Loads an image source into an HTMLImageElement asynchronously
 * @param {string} src
 * @returns {Promise<HTMLImageElement>}
 */
export function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (err) => reject(new Error('Failed to load image: ' + err));
    img.src = src;
  });
}

/**
 * Safely creates an Object URL from a File or Blob
 * @param {Blob|File} blob
 * @returns {string}
 */
export function createSafeObjectUrl(blob) {
  return URL.createObjectURL(blob);
}

/**
 * Revokes an Object URL to prevent memory leaks
 * @param {string} url
 */
export function revokeSafeObjectUrl(url) {
  if (url && url.startsWith('blob:')) {
    URL.revokeObjectURL(url);
  }
}

/**
 * Crops a rectangular region from an image and returns a transparent PNG Data URL
 * @param {HTMLImageElement} image
 * @param {{ x: number, y: number, width: number, height: number }} cropArea
 * @returns {string} cropped PNG Data URL
 */
export function cropImageToDataUrl(image, cropArea) {
  const canvas = document.createElement('canvas');
  const width = Math.max(1, Math.round(cropArea.width));
  const height = Math.max(1, Math.round(cropArea.height));

  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  // Clear to ensure transparent PNG preservation
  ctx.clearRect(0, 0, width, height);

  ctx.drawImage(
    image,
    Math.round(cropArea.x),
    Math.round(cropArea.y),
    width,
    height,
    0,
    0,
    width,
    height
  );

  return canvas.toDataURL('image/png');
}

