/**
 * Logo Engine
 * Handles manual cropping of the logo and geometric region suggestions.
 * Guaranteed manual cropping via Canvas API (Requirement 2).
 */

import { cropImageToDataUrl, loadImage } from '../utils/imageUtils.js';

export class LogoEngine {
  /**
   * Crops a region from the poster image to create the logo
   * @param {HTMLImageElement|string} posterSource
   * @param {{ x: number, y: number, width: number, height: number }} cropBox
   * @returns {Promise<string>} PNG Data URL of cropped logo
   */
  static async cropLogo(posterSource, cropBox) {
    const img = typeof posterSource === 'string' ? await loadImage(posterSource) : posterSource;
    return cropImageToDataUrl(img, cropBox);
  }

  /**
   * Provides initial geometric suggested regions for manual crop convenience.
   * (Standard geometric placement presets - NOT AI detection).
   * @param {HTMLImageElement|string} posterSource
   * @param {'bottom-left'|'bottom-right'|'bottom-center'|'top-left'} preset
   * @returns {Promise<{ x: number, y: number, width: number, height: number }|null>}
   */
  static async getSuggestedRegion(posterSource, preset = 'bottom-left') {
    try {
      const img = typeof posterSource === 'string' ? await loadImage(posterSource) : posterSource;
      const w = img.naturalWidth || img.width;
      const h = img.naturalHeight || img.height;

      const candW = Math.round(w * 0.28);
      const candH = Math.round(h * 0.14);

      let candX = Math.round(w * 0.05);
      let candY = Math.round(h * 0.82);

      if (preset === 'bottom-right') {
        candX = Math.round(w * 0.67);
      } else if (preset === 'bottom-center') {
        candX = Math.round((w - candW) / 2);
      } else if (preset === 'top-left') {
        candX = Math.round(w * 0.05);
        candY = Math.round(h * 0.05);
      }

      return {
        x: candX,
        y: candY,
        width: candW,
        height: candH
      };
    } catch (err) {
      console.warn('Suggested region calculation failed:', err);
      return null;
    }
  }
}
