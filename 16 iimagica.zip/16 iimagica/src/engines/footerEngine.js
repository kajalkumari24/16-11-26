/**
 * Footer Generation Engine
 * Responsible for loading templates, mapping colors, computing footer dimensions,
 * applying configurable logo and profile photo positioning, and dynamic brand details.
 */

import { getAllTemplates, loadSvgMarkup, compileSvgTemplate } from '../services/templateService.js';

export class FooterEngine {
  /**
   * Generates footer design variations matching the logo palette, poster dimensions,
   * logo positioning, optional profile photo, and dynamic brand details.
   * @param {{
   *   logo: string|null,
   *   colorPalette: { primary: string, secondary: string, accent: string, text: string },
   *   posterWidth: number,
   *   posterHeight: number,
   *   logoAlignment?: string,
   *   profilePicUrl?: string|null,
   *   profileShape?: string,
   *   brandDetails?: Object,
   *   customTemplates?: Array
   * }} params
   * @returns {Promise<Array<{
   *   id: string,
   *   name: string,
   *   category: string,
   *   colors: Object,
   *   width: number,
   *   height: number,
   *   logoConfig: Object,
   *   svgMarkup: string,
   *   compiledSvg: string
   * }>>}
   */
  static async generateFooters({
    logo,
    colorPalette,
    posterWidth,
    posterHeight,
    logoAlignment = 'left',
    profilePicUrl = null,
    profileShape = 'circle',
    brandDetails = null,
    customTemplates = []
  }) {
    const templates = [...customTemplates, ...getAllTemplates()];

    // Calculate suitable footer height based on poster dimensions (approx 13.5% of poster height)
    const baseHeight = Math.max(90, Math.round(posterHeight * 0.135));
    const targetWidth = Math.round(posterWidth);

    const generated = await Promise.all(
      templates.map(async (tmpl) => {
        try {
          // Compute proportionate footer height according to template aspect ratio (preserves curve aesthetics)
          let tmplHeight = baseHeight;
          if (tmpl.aspectRatio) {
            const [arW, arH] = tmpl.aspectRatio.split(':').map(Number);
            if (arW && arH) {
              const ratioFactor = arH / (arW * 0.18);
              tmplHeight = Math.min(Math.round(posterHeight * 0.28), Math.max(90, Math.round(baseHeight * ratioFactor)));
            }
          }

          // If custom uploaded template has an inline SVG markup or custom image
          let rawSvg = '';
          if (tmpl.customImageUrl) {
            rawSvg = `
              <svg viewBox="0 0 1000 180" xmlns="http://www.w3.org/2000/svg">
                <image href="${tmpl.customImageUrl}" x="0" y="0" width="1000" height="180" preserveAspectRatio="none" />
                <g class="logo-slot" transform="translate(45, 45)">
                  <rect width="180" height="90" rx="8" fill="rgba(255,255,255,0.1)" />
                </g>
              </svg>
            `;
          } else {
            rawSvg = await loadSvgMarkup(tmpl.file);
          }

          const compiledSvg = compileSvgTemplate(
            rawSvg,
            colorPalette,
            logo,
            targetWidth,
            tmplHeight,
            tmpl.logoConfig,
            logoAlignment,
            profilePicUrl,
            profileShape,
            brandDetails
          );

          return {
            id: tmpl.id,
            name: tmpl.name,
            category: tmpl.category,
            colors: { ...colorPalette },
            width: targetWidth,
            height: tmplHeight,
            logoConfig: tmpl.logoConfig,
            logoAlignment,
            profilePicUrl,
            profileShape,
            brandDetails,
            svgMarkup: rawSvg,
            compiledSvg
          };
        } catch (err) {
          console.warn(`Template ${tmpl.id} failed to load, skipping:`, err);
          return null;
        }
      })
    );

    return generated.filter(Boolean);
  }
}
