/**
 * Color Engine
 * Extracts dominant, secondary, accent, and text contrast colors from logo
 * with advanced transparency filtering and poster fallback (Requirement 6).
 */

import ColorThief from 'colorthief';
import { loadImage } from '../utils/imageUtils.js';
import {
  rgbToHex,
  getContrastTextColor,
  getColorDistance,
  shiftBrightness
} from '../utils/colorUtils.js';

export class ColorEngine {
  /**
   * Extracts a structured color palette from a logo image
   * @param {string} logoUrl - Image Data URL or Object URL
   * @param {string|null} fallbackPosterUrl - Fallback poster URL if logo has too few colors
   * @returns {Promise<{
   *   primary: string,
   *   secondary: string,
   *   accent: string,
   *   background: string,
   *   text: string
   * }>}
   */
  static async extractPalette(logoUrl, fallbackPosterUrl = null) {
    try {
      const img = await loadImage(logoUrl);
      const palette = await this._runExtraction(img);

      // If extracted palette has fewer than 2 distinct colors, supplement with poster colors
      if ((!palette || palette.length < 2) && fallbackPosterUrl) {
        console.info('Logo has limited opaque colors; supplementing with poster colors.');
        const posterImg = await loadImage(fallbackPosterUrl);
        const posterPalette = await this._runExtraction(posterImg);
        return this._formatPalette(posterPalette.length > 0 ? posterPalette : palette);
      }

      return this._formatPalette(palette);
    } catch (err) {
      console.warn('Extraction from logo failed, attempting poster fallback:', err);
      if (fallbackPosterUrl) {
        try {
          const posterImg = await loadImage(fallbackPosterUrl);
          const posterPalette = await this._runExtraction(posterImg);
          return this._formatPalette(posterPalette);
        } catch (posterErr) {
          console.error('Poster fallback extraction failed:', posterErr);
        }
      }

      // Safe default corporate palette
      return {
        primary: '#1E3A8A',
        secondary: '#0284C7',
        accent: '#F59E0B',
        background: '#FFFFFF',
        text: '#FFFFFF'
      };
    }
  }

  /**
   * Runs color extraction with strict transparent-pixel filtering (Requirement 6)
   */
  static async _runExtraction(img) {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    
    // Scale to standard analysis dimensions
    const maxDimension = 150;
    const scale = Math.min(1, maxDimension / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
    const w = Math.max(1, Math.round((img.naturalWidth || img.width || 100) * scale));
    const h = Math.max(1, Math.round((img.naturalHeight || img.height || 100) * scale));
    
    canvas.width = w;
    canvas.height = h;

    ctx.drawImage(img, 0, 0, w, h);
    const imgData = ctx.getImageData(0, 0, w, h).data;

    // Collect valid opaque pixels only (ignore transparency A < 125)
    const opaquePixelMap = {};
    let opaqueCount = 0;

    for (let i = 0; i < imgData.length; i += 4) {
      const a = imgData[i + 3];
      // Strictly ignore transparent and semi-transparent edge pixels
      if (a < 125) continue;

      const r = imgData[i];
      const g = imgData[i + 1];
      const b = imgData[i + 2];

      // Quantize to 32-step buckets to group similar shades
      const qr = Math.floor(r / 24) * 24;
      const qg = Math.floor(g / 24) * 24;
      const qb = Math.floor(b / 24) * 24;

      const key = `${qr},${qg},${qb}`;

      // Calculate saturation to favor rich brand colors over plain dull gray
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const delta = max - min;
      const sat = max === 0 ? 0 : delta / max;

      let score = 1;
      if (sat > 0.25) {
        score += sat * 3; // Boost vibrant logo colors
      }

      if (!opaquePixelMap[key]) {
        opaquePixelMap[key] = { r: qr, g: qg, b: qb, count: 0, score: 0 };
      }
      opaquePixelMap[key].count += 1;
      opaquePixelMap[key].score += score;
      opaqueCount++;
    }

    // If logo has almost no opaque pixels (e.g. completely blank transparent PNG)
    if (opaqueCount < 30) {
      return [];
    }

    // Try ColorThief on an opaque-flattened canvas if sufficient pixels
    try {
      const flatCanvas = document.createElement('canvas');
      flatCanvas.width = w;
      flatCanvas.height = h;
      const flatCtx = flatCanvas.getContext('2d');
      // Fill transparent areas with dominant color or neutral so ColorThief doesn't see black
      flatCtx.drawImage(img, 0, 0, w, h);
      
      const colorThief = new ColorThief();
      // Pass clean canvas to ColorThief
      const ctPalette = colorThief.getPalette(flatCanvas, 6);
      if (ctPalette && ctPalette.length > 0) {
        // Filter out any false black artifact caused by transparency
        const validCt = ctPalette.filter(([r, g, b]) => {
          const isNearBlack = r < 15 && g < 15 && b < 15;
          return !isNearBlack || opaquePixelMap[`0,0,0`];
        });
        if (validCt.length >= 2) {
          return validCt;
        }
      }
    } catch {
      // Fallback directly to our weighted pixel map
    }

    // Sort by weighted score
    return Object.values(opaquePixelMap)
      .sort((a, b) => b.score - a.score)
      .slice(0, 6)
      .map((c) => [c.r, c.g, c.b]);
  }

  /**
   * Formats raw RGB tuples into primary, secondary, accent, and text
   */
  static _formatPalette(rawColors) {
    if (!rawColors || rawColors.length === 0) {
      return {
        primary: '#1E3A8A',
        secondary: '#0284C7',
        accent: '#F59E0B',
        background: '#FFFFFF',
        text: '#FFFFFF'
      };
    }

    // Primary dominant color
    const c1 = rawColors[0];
    const primary = rgbToHex(c1[0], c1[1], c1[2]);

    // Secondary color with distinct color distance
    let c2 = rawColors.find((c) => {
      const dist = getColorDistance(
        { r: c1[0], g: c1[1], b: c1[2] },
        { r: c[0], g: c[1], b: c[2] }
      );
      return dist > 50;
    });

    if (!c2) {
      c2 = rawColors[1] || [c1[0], c1[1], c1[2]];
    }
    const secondary = rgbToHex(c2[0], c2[1], c2[2]);

    // Accent color
    let c3 = rawColors.find((c) => {
      const d1 = getColorDistance({ r: c1[0], g: c1[1], b: c1[2] }, { r: c[0], g: c[1], b: c[2] });
      const d2 = getColorDistance({ r: c2[0], g: c2[1], b: c2[2] }, { r: c[0], g: c[1], b: c[2] });
      return d1 > 45 && d2 > 45;
    });

    const accent = c3 ? rgbToHex(c3[0], c3[1], c3[2]) : shiftBrightness(secondary, 35);
    const text = getContrastTextColor(primary);

    return {
      primary,
      secondary,
      accent,
      background: '#FFFFFF',
      text
    };
  }
}
