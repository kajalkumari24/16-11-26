/**
 * Export Engine
 * Combines original poster and selected SVG footer at 1:1 original resolution
 * and triggers PNG download without duplicate logo rendering (Requirements 1, 5, 9).
 */

import { loadImage } from '../utils/imageUtils.js';

export class ExportEngine {
  /**
   * Combines original poster with selected footer and triggers download
   * @param {{
   *   posterUrl: string,
   *   posterWidth: number,
   *   posterHeight: number,
   *   selectedFooter: Object,
   *   filename?: string
   * }} params
   */
  static async exportPoster({
    posterUrl,
    posterWidth,
    posterHeight,
    selectedFooter,
    filename = 'poster-with-footer.png'
  }) {
    if (!posterUrl) throw new Error('No poster image available to export.');
    if (!selectedFooter) throw new Error('No footer selected.');

    const targetWidth = Math.round(posterWidth);
    const targetHeight = Math.round(posterHeight);

    // 1. Create Export Canvas preserving 100% of original poster dimensions (Requirement 9)
    const canvas = document.createElement('canvas');
    canvas.width = targetWidth;
    canvas.height = targetHeight;
    const ctx = canvas.getContext('2d');

    // 2. Draw Original Poster Image
    const posterImg = await loadImage(posterUrl);
    ctx.drawImage(posterImg, 0, 0, targetWidth, targetHeight);

    // 3. Render and Draw SVG Footer
    // Footer height matches the calculated proportion (13.5% of poster height)
    const footerHeight = selectedFooter.height || Math.round(targetHeight * 0.135);
    const footerY = targetHeight - footerHeight;

    // Ensure the SVG markup has explicit width, height and preserveAspectRatio attributes for canvas drawing
    let svgSource = selectedFooter.compiledSvg;
    if (!svgSource.includes('width=')) {
      svgSource = svgSource.replace(
        '<svg ',
        `<svg width="${targetWidth}" height="${footerHeight}" preserveAspectRatio="none" `
      );
    }

    // Convert compiled SVG into Blob URL
    const svgBlob = new Blob([svgSource], { type: 'image/svg+xml;charset=utf-8' });
    const svgUrl = URL.createObjectURL(svgBlob);

    try {
      const footerImg = await loadImage(svgUrl);

      // Draw the compiled SVG footer (which already includes the embedded logo in its exact slot)
      // NOTE: We do NOT draw the logo a second time. This prevents duplicate logo rendering (Requirement 1 & 5).
      ctx.drawImage(footerImg, 0, footerY, targetWidth, footerHeight);

      // 4. Convert Canvas to PNG Blob & Trigger Download
      return new Promise((resolve, reject) => {
        canvas.toBlob((blob) => {
          if (!blob) {
            return reject(new Error('Canvas export to blob failed.'));
          }
          const downloadUrl = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.download = filename;
          link.href = downloadUrl;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          setTimeout(() => URL.revokeObjectURL(downloadUrl), 2000);
          resolve(true);
        }, 'image/png');
      });
    } finally {
      URL.revokeObjectURL(svgUrl);
    }
  }
}
