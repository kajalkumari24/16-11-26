/**
 * Template Metadata Catalog
 * Defines the 10 footer templates with configurable logo positioning (Requirement 3).
 * Base SVG coordinate space is 1000 x 180.
 */

export const FOOTER_TEMPLATES = [
  {
    id: "rectangle-01",
    name: "Classic Rectangle",
    category: "rectangle",
    file: "/templates/rectangle.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 45,
      y: 42,
      width: 180,
      height: 96,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Solid, clean dual-tone corporate bar with crisp accent stripes"
  },
  {
    id: "wave-01",
    name: "Dynamic Wave",
    category: "wave",
    file: "/templates/wave.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 45,
      y: 70,
      width: 175,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Flowing Bézier curves with layered depth and accent highlight"
  },
  {
    id: "rounded-01",
    name: "Rounded Card",
    category: "rounded",
    file: "/templates/rounded.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 65,
      y: 42,
      width: 175,
      height: 96,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Elevated card with smooth rounded corners and vertical indicator"
  },
  {
    id: "diagonal-01",
    name: "Diagonal Cut",
    category: "diagonal",
    file: "/templates/diagonal.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 45,
      y: 58,
      width: 180,
      height: 96,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Modern architectural slant with dual-polygon geometry"
  },
  {
    id: "double-layer-01",
    name: "Double Layer",
    category: "double-layer",
    file: "/templates/double-layer.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 45,
      y: 60,
      width: 180,
      height: 88,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Two-tier stacked layout separating banner from contacts"
  },
  {
    id: "curved-01",
    name: "Convex Curved",
    category: "curved",
    file: "/templates/curved.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 45,
      y: 60,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Graceful arched dome curving upwards towards poster content"
  },
  {
    id: "ribbon-01",
    name: "Ribbon Banner",
    category: "ribbon",
    file: "/templates/ribbon.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 42,
      width: 180,
      height: 92,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Folded ribbon aesthetic with corner notches and border stitching"
  },
  {
    id: "floating-01",
    name: "Floating Pill",
    category: "floating",
    file: "/templates/floating.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 95,
      y: 48,
      width: 160,
      height: 84,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Sleek floating dock capsule with rounded pill silhouette"
  },
  {
    id: "transparent-01",
    name: "Glassmorphic Frost",
    category: "transparent",
    file: "/templates/transparent.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 45,
      y: 42,
      width: 180,
      height: 96,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Semi-transparent frost overlay with luminous border lines"
  },
  {
    id: "creative-01",
    name: "Creative Cutout",
    category: "creative",
    file: "/templates/creative.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 52,
      width: 180,
      height: 96,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:180",
    description: "Stepped geometric notch breakout for high visual impact"
  },
  {
    id: "wave-01-sunset",
    name: "Layered Sunset Wave",
    category: "wave",
    file: "/templates/wave/wave-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 185,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:300",
    description: "Cascading sunset curves with dark base wave and drop shadow accent"
  },
  {
    id: "wave-02-emerald",
    name: "Emerald Dual Wave",
    category: "wave",
    file: "/templates/wave/wave-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 195,
      width: 180,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:300",
    description: "Twin translucent gradient waves creating organic fluid motion"
  },
  {
    id: "wave-03-terracotta",
    name: "Terracotta Arch Wave",
    category: "wave",
    file: "/templates/wave/wave-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 395,
      width: 170,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:500",
    description: "Artistic boho arches, abstract organic blobs, and soft bottom wave"
  },
  {
    id: "wave-04-gold-blue",
    name: "Gold & Royal Wave",
    category: "wave",
    file: "/templates/wave/wave-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 55,
      y: 275,
      width: 180,
      height: 95,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:400",
    description: "Premium royal wave with gilded accent contour piping"
  },
  {
    id: "wave-05-vibrant",
    name: "Vibrant Dual Wave",
    category: "wave",
    file: "/templates/wave/wave-05.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 220,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:500",
    description: "Dynamic top and bottom multi-layered wave ribbons framing your brand"
  },
  {
    id: "wave-06-tiered",
    name: "Tiered Horizon Canvas",
    category: "wave",
    file: "/templates/wave/wave-06.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 360,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:800",
    description: "Deep structured multi-layer framing with top and bottom horizon strata"
  },
  {
    id: "wave-07-socials",
    name: "Neon Wave & Socials",
    category: "wave",
    file: "/templates/wave/wave-07.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 145,
      width: 180,
      height: 75,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:250",
    description: "Modern neon gradient wave footer with built-in social media icon cluster"
  },
  {
    id: "wave-08-spheres",
    name: "Cosmic Spheres Wave",
    category: "wave",
    file: "/templates/wave/wave-08.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 170,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:400",
    description: "Dual top and bottom wave crests accented by floating spheres and contour lines"
  },
  {
    id: "wave-09-shadow-cards",
    name: "Triple Tier Wave Cards",
    category: "wave",
    file: "/templates/wave/wave-09.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 520,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:700",
    description: "Multi-tier floating card banners with soft drop shadows and flowing gradients"
  },
  {
    id: "wave-10-ribbon-border",
    name: "Tri-Color Ribbon Wave",
    category: "wave",
    file: "/templates/wave/wave-10.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 270,
      width: 180,
      height: 95,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:600",
    description: "Dynamic top and bottom tri-color layered ribbon borders framing your content"
  },
  {
    id: "rectangle-01-pixel-grid",
    name: "Pixel Grid Banners",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 505,
      width: 160,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:700",
    description: "Modern rectangular banner cards flanked by dynamic pixel matrix grids"
  },
  {
    id: "rectangle-02-3d-cube",
    name: "3D Isometric Cube Deck",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 605,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:800",
    description: "Structured isometric 3D cube mesh wireframes with drop shadow elevation"
  },
  {
    id: "rectangle-03-bracket-matrix",
    name: "Minimalist Bracket Box",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 150,
      y: 150,
      width: 160,
      height: 95,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:400",
    description: "Clean minimalist framing with technical brackets and corner dot matrix"
  },
  {
    id: "rectangle-04-chevron-stripes",
    name: "Geometric Chevron Bar",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 465,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:650",
    description: "Angular diagonal chevron stripes separating header and brand details"
  },
  {
    id: "rectangle-05-triangle-mosaic",
    name: "Low-Poly Triangle Mosaic",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-05.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 495,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Triangular faceted mosaic mesh ribbons across clean corporate cards"
  },
  {
    id: "rectangle-06-halftone-grid",
    name: "Halftone Dot Matrix",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-06.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 495,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Tactile retro halftone dot screening overlay on warm rectangular cards"
  },
  {
    id: "rectangle-07-tech-border-badge",
    name: "Rounded Tech Badge Frame",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-07.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "right",
    logoConfig: {
      x: 425,
      y: 522,
      width: 135,
      height: 40,
      alignment: "right"
    },
    editable: true,
    aspectRatio: "600:600",
    description: "Rounded container stroke with bottom slanted info pill and dedicated logo badge"
  },
  {
    id: "rectangle-08-faceted-lowpoly",
    name: "Faceted Low-Poly Polygon",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-08.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 495,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Angular low-poly crystalline facets with overlapping architectural wireframes"
  },
  {
    id: "rectangle-09-chamfered-tech-bars",
    name: "Cyberpunk Chamfered Bars",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-09.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 440,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "600:600",
    description: "Futuristic chamfered cyber bars on top and bottom with technical polygon accents"
  },
  {
    id: "rectangle-10-neon-gradient-stripes",
    name: "Neon Ribbon Stripes",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-10.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 495,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Vibrant neon slanted gradient bands contrasting over sleek dark slate cards"
  },
  {
    id: "rounded-01-stitched-capsule",
    name: "Stitched Pill Capsules",
    category: "rounded",
    file: "/templates/rounded/rounded-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 100,
      y: 547,
      width: 70,
      height: 70,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "600:700",
    description: "Rounded capsule tags with stitched perimeter dashes and circular logo badge"
  },
  {
    id: "rounded-02-spiral-dots",
    name: "Spiral Halftone Cards",
    category: "rounded",
    file: "/templates/rounded/rounded-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 475,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:650",
    description: "Smooth elevated cards accented by radial spiral vortex dot constellations"
  },
  {
    id: "rounded-03-curved-notch-grid",
    name: "Curved Notch Badge Grid",
    category: "rounded",
    file: "/templates/rounded/rounded-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 350,
      y: 470,
      width: 180,
      height: 60,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:600",
    description: "Multi-row matrix of compact rounded badges with curved top notch accents"
  },
  {
    id: "rounded-04-gradient-banner-bars",
    name: "Pinpoint Header Bars",
    category: "rounded",
    file: "/templates/rounded/rounded-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 375,
      width: 160,
      height: 50,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "700:500",
    description: "Rounded corner gradient banner headers framed by technical pin indicator strokes"
  },
  {
    id: "rounded-05-meteor-orb",
    name: "Meteor Pill & 3D Orb",
    category: "rounded",
    file: "/templates/rounded/rounded-05.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 80,
      y: 470,
      width: 180,
      height: 50,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "600:650",
    description: "Rounded pill capsule with speed notches and a dimensional shaded spherical orb"
  },
  {
    id: "rounded-06-bullseye-ribbon",
    name: "Concentric Target Ribbon",
    category: "rounded",
    file: "/templates/rounded/rounded-06.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 45,
      y: 470,
      width: 70,
      height: 70,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "500:650",
    description: "Pill banner body flanked by a concentric circular bullseye target badge"
  },
  {
    id: "rounded-07-gloss-glass-pill",
    name: "Glossy Glass Pill Buttons",
    category: "rounded",
    file: "/templates/rounded/rounded-07.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 42,
      y: 482,
      width: 56,
      height: 56,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "400:700",
    description: "High-gloss pill buttons with reflective gloss overlays and circular icon slots"
  },
  {
    id: "rounded-08-organic-droplet-badge",
    name: "Fluid Droplet Badges",
    category: "rounded",
    file: "/templates/rounded/rounded-08.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 62,
      y: 472,
      width: 56,
      height: 56,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "500:650",
    description: "Fluid organic liquid droplets curling around circular badge rings on pill bars"
  },
  {
    id: "rectangle-01-pixel-grid",
    name: "Pixel Grid Banners",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 505,
      width: 160,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:700",
    description: "Modern rectangular banner cards flanked by dynamic pixel matrix grids"
  },
  {
    id: "rectangle-02-3d-cube",
    name: "3D Isometric Cube Deck",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 605,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:800",
    description: "Structured isometric 3D cube mesh wireframes with drop shadow elevation"
  },
  {
    id: "rectangle-03-bracket-matrix",
    name: "Minimalist Bracket Box",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 150,
      y: 150,
      width: 160,
      height: 95,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:400",
    description: "Clean minimalist framing with technical brackets and corner dot matrix"
  },
  {
    id: "rectangle-04-chevron-stripes",
    name: "Geometric Chevron Bar",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 465,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:650",
    description: "Angular diagonal chevron stripes separating header and brand details"
  },
  {
    id: "rectangle-05-triangle-mosaic",
    name: "Low-Poly Triangle Mosaic",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-05.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 495,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Triangular faceted mosaic mesh ribbons across clean corporate cards"
  },
  {
    id: "rectangle-06-halftone-grid",
    name: "Halftone Dot Matrix",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-06.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 495,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Tactile retro halftone dot screening overlay on warm rectangular cards"
  },
  {
    id: "rectangle-07-tech-border-badge",
    name: "Rounded Tech Badge Frame",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-07.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "right",
    logoConfig: {
      x: 425,
      y: 522,
      width: 135,
      height: 40,
      alignment: "right"
    },
    editable: true,
    aspectRatio: "600:600",
    description: "Rounded container stroke with bottom slanted info pill and dedicated logo badge"
  },
  {
    id: "rectangle-08-faceted-lowpoly",
    name: "Faceted Low-Poly Polygon",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-08.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 495,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Angular low-poly crystalline facets with overlapping architectural wireframes"
  },
  {
    id: "rectangle-09-chamfered-tech-bars",
    name: "Cyberpunk Chamfered Bars",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-09.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 440,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "600:600",
    description: "Futuristic chamfered cyber bars on top and bottom with technical polygon accents"
  },
  {
    id: "rectangle-10-neon-gradient-stripes",
    name: "Neon Ribbon Stripes",
    category: "rectangle",
    file: "/templates/rectangle/rectangle-10.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 495,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Vibrant neon slanted gradient bands contrasting over sleek dark slate cards"
  },
  {
    id: "rounded-01-stitched-capsule",
    name: "Stitched Pill Capsules",
    category: "rounded",
    file: "/templates/rounded/rounded-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 100,
      y: 547,
      width: 70,
      height: 70,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "600:700",
    description: "Rounded capsule tags with stitched perimeter dashes and circular logo badge"
  },
  {
    id: "rounded-02-spiral-dots",
    name: "Spiral Halftone Cards",
    category: "rounded",
    file: "/templates/rounded/rounded-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 475,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:650",
    description: "Smooth elevated cards accented by radial spiral vortex dot constellations"
  },
  {
    id: "rounded-03-curved-notch-grid",
    name: "Curved Notch Badge Grid",
    category: "rounded",
    file: "/templates/rounded/rounded-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 350,
      y: 470,
      width: 180,
      height: 60,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:600",
    description: "Multi-row matrix of compact rounded badges with curved top notch accents"
  },
  {
    id: "rounded-04-gradient-banner-bars",
    name: "Pinpoint Header Bars",
    category: "rounded",
    file: "/templates/rounded/rounded-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 375,
      width: 160,
      height: 50,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "700:500",
    description: "Rounded corner gradient banner headers framed by technical pin indicator strokes"
  },
  {
    id: "rounded-05-meteor-orb",
    name: "Meteor Pill & 3D Orb",
    category: "rounded",
    file: "/templates/rounded/rounded-05.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 80,
      y: 470,
      width: 180,
      height: 50,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "600:650",
    description: "Rounded pill capsule with speed notches and a dimensional shaded spherical orb"
  },
  {
    id: "rounded-06-bullseye-ribbon",
    name: "Concentric Target Ribbon",
    category: "rounded",
    file: "/templates/rounded/rounded-06.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 45,
      y: 470,
      width: 70,
      height: 70,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "500:650",
    description: "Pill banner body flanked by a concentric circular bullseye target badge"
  },
  {
    id: "rounded-07-gloss-glass-pill",
    name: "Glossy Glass Pill Buttons",
    category: "rounded",
    file: "/templates/rounded/rounded-07.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 42,
      y: 482,
      width: 56,
      height: 56,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "400:700",
    description: "High-gloss pill buttons with reflective gloss overlays and circular icon slots"
  },
  {
    id: "rounded-08-organic-droplet-badge",
    name: "Fluid Droplet Badges",
    category: "rounded",
    file: "/templates/rounded/rounded-08.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 62,
      y: 472,
      width: 56,
      height: 56,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "500:650",
    description: "Fluid organic liquid droplets curling around circular badge rings on pill bars"
  },
  {
    id: "circle-01-flowing-ring-bar",
    name: "Flowing Ring Badge Bar",
    category: "circle",
    file: "/templates/circle/circle-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 150,
      y: 120,
      width: 100,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:300",
    description: "Flowing horizontal gradient bar with wave tail contours and a circular badge ring"
  },
  {
    id: "circle-02-clock-dial-capsule",
    name: "Clock Dial Progress Capsule",
    category: "circle",
    file: "/templates/circle/circle-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 140,
      y: 145,
      width: 90,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:400",
    description: "Cyan capsule banner with an upper tab and arrowed circular clock dial badge"
  },
  {
    id: "circle-03-curved-arch-ribbons",
    name: "Concentric Curve Arch",
    category: "circle",
    file: "/templates/circle/circle-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 270,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:450",
    description: "Arching circular wave contours and smooth curve cutouts on crisp white cards"
  },
  {
    id: "circle-04-bubble-cluster-capsule",
    name: "Floating Bubble Orb Deck",
    category: "circle",
    file: "/templates/circle/circle-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 260,
      y: 225,
      width: 140,
      height: 140,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:600",
    description: "Horizontal capsule flanked by an array of floating gradient bubbles and central orb"
  },
  {
    id: "circle-05-interlocking-discs",
    name: "Interlocking Disc Clusters",
    category: "circle",
    file: "/templates/circle/circle-05.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 70,
      y: 465,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:650",
    description: "Modern cards framed by overlapping bold geometric circular disc clusters"
  },
  {
    id: "circle-06-ocean-wave-ring",
    name: "Ocean Wave Ring Badge",
    category: "circle",
    file: "/templates/circle/circle-06.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 55,
      y: 435,
      width: 90,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:600",
    description: "Deep ocean wave footer with a prominent concentric triple-ring circular logo badge"
  },
  {
    id: "circle-07-badge-stepper-header",
    name: "Numbered Stepper Badge Bar",
    category: "circle",
    file: "/templates/circle/circle-07.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 125,
      y: 465,
      width: 90,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:650",
    description: "Ribbon header with circular logo badge frame and numbered bullet step markers"
  },
  {
    id: "circle-08-brush-swirl-rings",
    name: "Dynamic Swirl Brush Rings",
    category: "circle",
    file: "/templates/circle/circle-08.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 250,
      y: 500,
      width: 90,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:700",
    description: "Expressive circular dashed brushstroke swirl rings with drop shadow white disc centers"
  },
  {
    id: "ribbon-01-cyber-glow",
    name: "Cyber Neon Wave Ribbons",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 200,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:500",
    description: "Deep cyberspace background with glowing multi-tier cyber wave ribbon trails"
  },
  {
    id: "ribbon-02-crimson-weave",
    name: "Crimson Weave Diagonal Ribbons",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 480,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "700:900",
    description: "Top and bottom interlocking dynamic diagonal ribbon folds and fabric crossings"
  },
  {
    id: "ribbon-03-metallic-gold-swirl",
    name: "Metallic Gold Swirl Ribbons",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 260,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:400",
    description: "Symmetrical metallic gold swirl ribbon flourishes framing central brand content"
  },
  {
    id: "ribbon-04-gilded-banner-wings",
    name: "Gilded Wing Ribbon Banner",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 90,
      y: 115,
      width: 160,
      height: 75,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:350",
    description: "Classic royal banner ribbon with gold backing wings and crisp inner contour strokes"
  },
  {
    id: "ribbon-05-3d-scroll-curl",
    name: "3D Curled Scroll Ribbon",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-05.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 180,
      y: 160,
      width: 180,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:450",
    description: "Dimensional parchment ribbon with gilded borders and realistic curled scroll end tails"
  },
  {
    id: "ribbon-06-folded-royal-bar",
    name: "Folded Royal Notch Ribbon",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-06.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 120,
      y: 85,
      width: 160,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:300",
    description: "Elevated front horizontal ribbon bar with folded back extensions and chevron notch tails"
  },
  {
    id: "diagonal-01-slanted-corner",
    name: "Teal Slanted Geometric Corner",
    category: "diagonal",
    file: "/templates/diagonal/diagonal-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 380,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "600:600",
    description: "Modern teal canvas with top-left white cutout corner, cream diagonal bars, and bold pink accents"
  },
  {
    id: "diagonal-02-foliage-ribbon",
    name: "Foliage Ribbon Diagonal",
    category: "diagonal",
    file: "/templates/diagonal/diagonal-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 180,
      y: 135,
      width: 160,
      height: 70,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:400",
    description: "Deep navy ribbon chevron banner flanked by delicate line-art foliage and soft lavender accent blobs"
  },
  {
    id: "diagonal-03-cyan-slash",
    name: "Navy Wedge & Cyan Slash",
    category: "diagonal",
    file: "/templates/diagonal/diagonal-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 80,
      y: 240,
      width: 200,
      height: 95,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:600",
    description: "Clean dual-tone corporate layout with bold navy angled wedges and energetic cyan diagonal slash"
  },
  {
    id: "diagonal-04-multi-bands",
    name: "Layered Blue Slanted Bands",
    category: "diagonal",
    file: "/templates/diagonal/diagonal-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 100,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:300",
    description: "Dynamic geometric composition with intersecting sky blue and royal blue diagonal stripes"
  },
  {
    id: "ribbon-01-cyber-glow",
    name: "Cyber Neon Wave Ribbons",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 200,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:500",
    description: "Deep cyberspace background with glowing multi-tier cyber wave ribbon trails"
  },
  {
    id: "ribbon-02-crimson-weave",
    name: "Crimson Weave Diagonal Ribbons",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 480,
      width: 180,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "700:900",
    description: "Top and bottom interlocking dynamic diagonal ribbon folds and fabric crossings"
  },
  {
    id: "ribbon-03-metallic-gold-swirl",
    name: "Metallic Gold Swirl Ribbons",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 260,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:400",
    description: "Symmetrical metallic gold swirl ribbon flourishes framing central brand content"
  },
  {
    id: "ribbon-04-gilded-banner-wings",
    name: "Gilded Wing Ribbon Banner",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 90,
      y: 115,
      width: 160,
      height: 75,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:350",
    description: "Classic royal banner ribbon with gold backing wings and crisp inner contour strokes"
  },
  {
    id: "ribbon-05-3d-scroll-curl",
    name: "3D Curled Scroll Ribbon",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-05.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 180,
      y: 160,
      width: 180,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:450",
    description: "Dimensional parchment ribbon with gilded borders and realistic curled scroll end tails"
  },
  {
    id: "ribbon-06-folded-royal-bar",
    name: "Folded Royal Notch Ribbon",
    category: "ribbon",
    file: "/templates/ribbon/ribbon-06.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 120,
      y: 85,
      width: 160,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:300",
    description: "Elevated front horizontal ribbon bar with folded back extensions and chevron notch tails"
  },
  {
    id: "diagonal-01-slanted-corner",
    name: "Teal Slanted Geometric Corner",
    category: "diagonal",
    file: "/templates/diagonal/diagonal-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 50,
      y: 380,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "600:600",
    description: "Modern teal canvas with top-left white cutout corner, cream diagonal bars, and bold pink accents"
  },
  {
    id: "diagonal-02-foliage-ribbon",
    name: "Foliage Ribbon Diagonal",
    category: "diagonal",
    file: "/templates/diagonal/diagonal-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 180,
      y: 135,
      width: 160,
      height: 70,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "800:400",
    description: "Deep navy ribbon chevron banner flanked by delicate line-art foliage and soft lavender accent blobs"
  },
  {
    id: "diagonal-03-cyan-slash",
    name: "Navy Wedge & Cyan Slash",
    category: "diagonal",
    file: "/templates/diagonal/diagonal-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 80,
      y: 240,
      width: 200,
      height: 95,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:600",
    description: "Clean dual-tone corporate layout with bold navy angled wedges and energetic cyan diagonal slash"
  },
  {
    id: "diagonal-04-multi-bands",
    name: "Layered Blue Slanted Bands",
    category: "diagonal",
    file: "/templates/diagonal/diagonal-04.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 100,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:300",
    description: "Dynamic geometric composition with intersecting sky blue and royal blue diagonal stripes"
  },
  {
    id: "double-layer-01-slate-subscribe",
    name: "Slate Corporate Subscribe Double Layer",
    category: "double-layer",
    file: "/templates/double-layer/double-layer-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 105,
      width: 180,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:500",
    description: "Two-tier slate footer with subscribe form inputs, social badge tier, and dark copyright bar"
  },
  {
    id: "double-layer-02-floating-card-wave",
    name: "Blue Floating Card & Wave Double Layer",
    category: "double-layer",
    file: "/templates/double-layer/double-layer-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 280,
      y: 125,
      width: 180,
      height: 45,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:550",
    description: "Layered card with elevated blue floating title bar and contrasting dark bottom wave silhouette"
  },
  {
    id: "double-layer-03-contact-split",
    name: "Split Contact Icons & Green Banner",
    category: "double-layer",
    file: "/templates/double-layer/double-layer-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 220,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:350",
    description: "Two-stage split footer featuring top light contact icon strip and bottom solid green brand banner"
  },
  {
    id: "creative-01-purple-curve",
    name: "Purple Curve Header Creative",
    category: "creative",
    file: "/templates/creative/creative-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 100,
      y: 150,
      width: 200,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:500",
    description: "Bold dark top bar with sweeping royal purple curved container and sleek minimalist newsletter input"
  },
  {
    id: "creative-02-memphis-wave",
    name: "Memphis Pop & Wave Creative",
    category: "creative",
    file: "/templates/creative/creative-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 90,
      y: 70,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:550",
    description: "Energetic Memphis design with vibrant yellow base, floating geometric accents, and dark navy bottom wave"
  },
  {
    id: "creative-03-forest-card",
    name: "Olive Frame & Forest Card Creative",
    category: "creative",
    file: "/templates/creative/creative-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 100,
      y: 180,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:450",
    description: "Sophisticated editorial card with olive margins, off-white enclosure, and dark forest green footer"
  },
  {
    id: "double-layer-01-slate-subscribe",
    name: "Slate Corporate Subscribe Double Layer",
    category: "double-layer",
    file: "/templates/double-layer/double-layer-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 105,
      width: 180,
      height: 80,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:500",
    description: "Two-tier slate footer with subscribe form inputs, social badge tier, and dark copyright bar"
  },
  {
    id: "double-layer-02-floating-card-wave",
    name: "Blue Floating Card & Wave Double Layer",
    category: "double-layer",
    file: "/templates/double-layer/double-layer-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 280,
      y: 125,
      width: 180,
      height: 45,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:550",
    description: "Layered card with elevated blue floating title bar and contrasting dark bottom wave silhouette"
  },
  {
    id: "double-layer-03-contact-split",
    name: "Split Contact Icons & Green Banner",
    category: "double-layer",
    file: "/templates/double-layer/double-layer-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 60,
      y: 220,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "900:350",
    description: "Two-stage split footer featuring top light contact icon strip and bottom solid green brand banner"
  },
  {
    id: "creative-01-purple-curve",
    name: "Purple Curve Header Creative",
    category: "creative",
    file: "/templates/creative/creative-01.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 100,
      y: 150,
      width: 200,
      height: 90,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:500",
    description: "Bold dark top bar with sweeping royal purple curved container and sleek minimalist newsletter input"
  },
  {
    id: "creative-02-memphis-wave",
    name: "Memphis Pop & Wave Creative",
    category: "creative",
    file: "/templates/creative/creative-02.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 90,
      y: 70,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:550",
    description: "Energetic Memphis design with vibrant yellow base, floating geometric accents, and dark navy bottom wave"
  },
  {
    id: "creative-03-forest-card",
    name: "Olive Frame & Forest Card Creative",
    category: "creative",
    file: "/templates/creative/creative-03.svg",
    supportedColors: ["primary", "secondary", "accent"],
    logoPosition: "left",
    logoConfig: {
      x: 100,
      y: 180,
      width: 180,
      height: 85,
      alignment: "left"
    },
    editable: true,
    aspectRatio: "1000:450",
    description: "Sophisticated editorial card with olive margins, off-white enclosure, and dark forest green footer"
  }
];
