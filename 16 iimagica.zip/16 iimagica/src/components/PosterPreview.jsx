import React, { useState } from 'react';

export default function PosterPreview({ poster, selectedFooter, onPosterDropped }) {
  const [isDragOver, setIsDragOver] = useState(false);

  if (!poster) {
    return (
      <div className="card-section" style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--text-muted)' }}>
        <p>Upload a poster to see the live preview with your generated footer designs.</p>
      </div>
    );
  }

  // Calculate footer relative height percentage so it fits the poster proportionately
  const footerPercent = selectedFooter && poster.height
    ? (selectedFooter.height / poster.height) * 100
    : 13.5;

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file && onPosterDropped) {
      onPosterDropped(file);
    }
  };

  return (
    <div className="card-section preview-section">
      <div className="section-title">
        <span>Poster Live Preview</span>
        {selectedFooter && (
          <span style={{ fontSize: '12px', fontWeight: 'bold', color: 'var(--primary-color)' }}>
            Active Footer: {selectedFooter.name}
          </span>
        )}
      </div>

      <div className="preview-container">
        <div
          className="poster-canvas-frame"
          style={{
            maxWidth: '560px',
            width: '100%',
            position: 'relative',
            outline: isDragOver ? '3px dashed #2563eb' : 'none',
            outlineOffset: '-4px',
            transition: 'outline 0.15s'
          }}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {/* Main Original Poster Image */}
          <img
            src={poster.url}
            alt={poster.name}
            className="poster-main-image"
            style={{ width: '100%', height: 'auto', display: 'block' }}
          />

          {isDragOver && (
            <div style={{
              position: 'absolute',
              inset: 0,
              backgroundColor: 'rgba(37, 99, 235, 0.4)',
              backdropFilter: 'blur(3px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffffff',
              fontSize: '18px',
              fontWeight: '700',
              zIndex: 20
            }}>
              📥 Drop to Replace Poster Image
            </div>
          )}

          {/* Selected Footer Dock Overlay */}
          {selectedFooter && (
            <div
              className="preview-footer-dock"
              style={{
                position: 'absolute',
                bottom: 0,
                left: 0,
                width: '100%',
                height: `${footerPercent}%`,
                pointerEvents: 'none',
                display: 'flex',
                alignItems: 'flex-end'
              }}
              dangerouslySetInnerHTML={{ __html: selectedFooter.compiledSvg }}
            />
          )}
        </div>
      </div>
    </div>
  );
}
