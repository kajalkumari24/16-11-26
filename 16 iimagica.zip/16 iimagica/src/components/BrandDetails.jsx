import React from 'react';

export default function BrandDetails({ brandDetails, onChangeBrandDetails }) {
  const updateField = (field, value) => {
    onChangeBrandDetails({
      ...brandDetails,
      [field]: value
    });
  };

  const addCustomField = (defaultLabel = 'Detail', defaultValue = '') => {
    const newField = {
      id: `cf-${Date.now()}`,
      label: defaultLabel,
      value: defaultValue
    };
    onChangeBrandDetails({
      ...brandDetails,
      customFields: [...(brandDetails.customFields || []), newField]
    });
  };

  const updateCustomField = (id, key, val) => {
    const updated = (brandDetails.customFields || []).map((f) => {
      if (f.id === id) {
        return { ...f, [key]: val };
      }
      return f;
    });
    onChangeBrandDetails({
      ...brandDetails,
      customFields: updated
    });
  };

  const removeCustomField = (id) => {
    const filtered = (brandDetails.customFields || []).filter((f) => f.id !== id);
    onChangeBrandDetails({
      ...brandDetails,
      customFields: filtered
    });
  };

  return (
    <div className="card-section" style={{ margin: '16px 0', padding: '18px 20px' }}>
      <div className="section-title" style={{ marginBottom: '14px' }}>
        <span>Brand Details & Contacts</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '12px' }}>
        {/* Name */}
        <div>
          <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
            Full Name
          </label>
          <input
            type="text"
            className="form-input"
            style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--border-color)', fontSize: '13px' }}
            placeholder="e.g. Rajesh Sharma"
            value={brandDetails.name || ''}
            onChange={(e) => updateField('name', e.target.value)}
          />
        </div>

        {/* Company */}
        <div>
          <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
            Company Name
          </label>
          <input
            type="text"
            className="form-input"
            style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--border-color)', fontSize: '13px' }}
            placeholder="e.g. IIMAGICA Tech Ventures"
            value={brandDetails.company || ''}
            onChange={(e) => updateField('company', e.target.value)}
          />
        </div>

        {/* Phone */}
        <div>
          <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
            Phone Number
          </label>
          <input
            type="text"
            className="form-input"
            style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--border-color)', fontSize: '13px' }}
            placeholder="e.g. +91 98765 43210"
            value={brandDetails.phone || ''}
            onChange={(e) => updateField('phone', e.target.value)}
          />
        </div>

        {/* Email */}
        <div>
          <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
            Email Address
          </label>
          <input
            type="email"
            className="form-input"
            style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--border-color)', fontSize: '13px' }}
            placeholder="e.g. connect@iimagica.com"
            value={brandDetails.email || ''}
            onChange={(e) => updateField('email', e.target.value)}
          />
        </div>

        {/* Website */}
        <div>
          <label style={{ fontSize: '12px', fontWeight: '600', color: '#475569', display: 'block', marginBottom: '4px' }}>
            Website
          </label>
          <input
            type="text"
            className="form-input"
            style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--border-color)', fontSize: '13px' }}
            placeholder="e.g. www.iimagica.com"
            value={brandDetails.website || ''}
            onChange={(e) => updateField('website', e.target.value)}
          />
        </div>
      </div>

      {/* DYNAMIC ADDITIONAL BRAND DETAILS SECTION */}
      <div style={{ marginTop: '18px', paddingTop: '14px', borderTop: '1px solid var(--border-color)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
          <div>
            <span style={{ fontSize: '13px', fontWeight: '700', color: '#1e293b' }}>
              Dynamic Brand Details (Custom Badges in Footer)
            </span>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
              Add extra details like Government Reg No., RERA License, ISO Standards, or Taglines
            </div>
          </div>

          <button
            type="button"
            className="btn btn-primary"
            style={{ padding: '6px 12px', fontSize: '12px' }}
            onClick={() => addCustomField('Detail', 'Value')}
          >
            <span>➕</span> Add More Brand Detail
          </button>
        </div>

        {/* List of Custom Dynamic Detail Fields */}
        {(brandDetails.customFields || []).length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '12px' }}>
            {(brandDetails.customFields || []).map((cf) => (
              <div key={cf.id} style={{ display: 'flex', gap: '8px', alignItems: 'center', background: '#f8fafc', padding: '6px 10px', borderRadius: '6px', border: '1px solid var(--border-color)' }}>
                <input
                  type="text"
                  placeholder="Label (e.g. Govt Reg)"
                  value={cf.label}
                  style={{ width: '160px', padding: '6px 8px', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '12px', fontWeight: '600' }}
                  onChange={(e) => updateCustomField(cf.id, 'label', e.target.value)}
                />
                <span style={{ color: 'var(--text-muted)' }}>:</span>
                <input
                  type="text"
                  placeholder="Value (e.g. REG-88492)"
                  value={cf.value}
                  style={{ flex: 1, padding: '6px 8px', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '12px' }}
                  onChange={(e) => updateCustomField(cf.id, 'value', e.target.value)}
                />
                <button
                  type="button"
                  style={{ background: 'transparent', border: 'none', color: '#dc2626', cursor: 'pointer', padding: '4px 8px', fontSize: '14px' }}
                  title="Remove Detail"
                  onClick={() => removeCustomField(cf.id)}
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ fontSize: '12px', color: 'var(--text-muted)', fontStyle: 'italic', marginBottom: '8px' }}>
            No additional brand details added yet. Click &quot;Add More Brand Detail&quot; or choose a quick preset below.
          </div>
        )}

        {/* Quick Presets */}
        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '11px', color: 'var(--text-muted)', alignSelf: 'center', marginRight: '4px' }}>
            Quick add:
          </span>
          <button
            type="button"
            className="btn btn-secondary"
            style={{ padding: '3px 8px', fontSize: '11px' }}
            onClick={() => addCustomField('Govt Reg', 'REG-2026-8849')}
          >
            + Govt Reg
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            style={{ padding: '3px 8px', fontSize: '11px' }}
            onClick={() => addCustomField('ISO Standard', 'ISO 9001:2015')}
          >
            + ISO Standard
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            style={{ padding: '3px 8px', fontSize: '11px' }}
            onClick={() => addCustomField('RERA Approved', 'PRM/KA/1251')}
          >
            + RERA ID
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            style={{ padding: '3px 8px', fontSize: '11px' }}
            onClick={() => addCustomField('Tagline', 'Excellence in Quality')}
          >
            + Tagline
          </button>
        </div>
      </div>
    </div>
  );
}

