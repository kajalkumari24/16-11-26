import React, { useRef, useState, useEffect, useCallback } from 'react';
import { LogoEngine } from '../engines/logoEngine';
import { validateImageFile } from '../utils/validation';

export default function LogoSelector({
  poster,
  logoUrl,
  onLogoSelected,
  onLogoFileUploaded,
  profilePicUrl,
  onProfilePicSelected,
  onRemoveProfilePic,
  profileShape,
  onProfileShapeChanged,
  isOpen,
  onOpenCropModal,
  onCloseCropModal
}) {
  const canvasRef = useRef(null);
  const logoInputRef = useRef(null);
  const profileInputRef = useRef(null);

  const [isDrawing, setIsDrawing] = useState(false);
  const [startPoint, setStartPoint] = useState({ x: 0, y: 0 });
  const [cropBox, setCropBox] = useState({ x: 0, y: 0, width: 0, height: 0 });
  const [imageObj, setImageObj] = useState(null);

  const [logoDragOver, setLogoDragOver] = useState(false);
  const [profileDragOver, setProfileDragOver] = useState(false);

  // Initialize canvas and image on modal open
  useEffect(() => {
    if (!poster || !isOpen) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = poster.url;
    img.onload = () => {
      setImageObj(img);
      const canvas = canvasRef.current;
      if (!canvas) return;

      const maxW = Math.min(580, window.innerWidth - 60);
      const scale = Math.min(1, maxW / img.naturalWidth);
      const canvasW = Math.round(img.naturalWidth * scale);
      const canvasH = Math.round(img.naturalHeight * scale);

      canvas.width = canvasW;
      canvas.height = canvasH;

      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, 0, 0, canvasW, canvasH);

      LogoEngine.getSuggestedRegion(img, 'bottom-left').then((preset) => {
        if (preset) {
          setCropBox({
            x: Math.round(preset.x * scale),
            y: Math.round(preset.y * scale),
            width: Math.round(preset.width * scale),
            height: Math.round(preset.height * scale)
          });
        }
      });
    };
  }, [poster, isOpen]);

  // Redraw canvas with crop overlay
  const redraw = useCallback(() => {
    if (!imageObj || !canvasRef.current || !isOpen) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    ctx.drawImage(imageObj, 0, 0, canvas.width, canvas.height);

    if (cropBox.width > 5 && cropBox.height > 5) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.clearRect(cropBox.x, cropBox.y, cropBox.width, cropBox.height);
      ctx.drawImage(
        imageObj,
        (cropBox.x / canvas.width) * imageObj.naturalWidth,
        (cropBox.y / canvas.height) * imageObj.naturalHeight,
        (cropBox.width / canvas.width) * imageObj.naturalWidth,
        (cropBox.height / canvas.height) * imageObj.naturalHeight,
        cropBox.x,
        cropBox.y,
        cropBox.width,
        cropBox.height
      );

      ctx.strokeStyle = '#2563eb';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(cropBox.x, cropBox.y, cropBox.width, cropBox.height);

      ctx.fillStyle = '#ffffff';
      const handleSize = 6;
      ctx.fillRect(cropBox.x - 3, cropBox.y - 3, handleSize, handleSize);
      ctx.fillRect(cropBox.x + cropBox.width - 3, cropBox.y - 3, handleSize, handleSize);
      ctx.fillRect(cropBox.x - 3, cropBox.y + cropBox.height - 3, handleSize, handleSize);
      ctx.fillRect(cropBox.x + cropBox.width - 3, cropBox.y + cropBox.height - 3, handleSize, handleSize);
    }
  }, [cropBox, imageObj, isOpen]);

  useEffect(() => {
    redraw();
  }, [redraw]);

  // Unified Mouse & Touch coordinate calculator
  const getPointerCoords = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    const clientX = e.touches && e.touches.length > 0 ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches && e.touches.length > 0 ? e.touches[0].clientY : e.clientY;

    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
      x: Math.max(0, Math.min(canvas.width, (clientX - rect.left) * scaleX)),
      y: Math.max(0, Math.min(canvas.height, (clientY - rect.top) * scaleY))
    };
  };

  const handlePointerDown = (e) => {
    const { x, y } = getPointerCoords(e);
    setStartPoint({ x, y });
    setIsDrawing(true);
    setCropBox({ x, y, width: 0, height: 0 });
  };

  const handlePointerMove = (e) => {
    if (!isDrawing) return;
    if (e.cancelable) e.preventDefault();

    const { x: currentX, y: currentY } = getPointerCoords(e);
    const x = Math.min(startPoint.x, currentX);
    const y = Math.min(startPoint.y, currentY);
    const width = Math.abs(currentX - startPoint.x);
    const height = Math.abs(currentY - startPoint.y);

    setCropBox({ x, y, width, height });
  };

  const handlePointerUp = () => {
    setIsDrawing(false);
  };

  const applyPresetRegion = async (preset) => {
    if (!imageObj || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const scale = canvas.width / (imageObj.naturalWidth || 1);
    const region = await LogoEngine.getSuggestedRegion(imageObj, preset);
    if (region) {
      setCropBox({
        x: Math.round(region.x * scale),
        y: Math.round(region.y * scale),
        width: Math.round(region.width * scale),
        height: Math.round(region.height * scale)
      });
    }
  };

  const handleApplyCrop = async () => {
    if (!imageObj || cropBox.width < 10 || cropBox.height < 10) {
      onCloseCropModal();
      return;
    }

    const canvas = canvasRef.current;
    const scaleX = imageObj.naturalWidth / canvas.width;
    const scaleY = imageObj.naturalHeight / canvas.height;

    const naturalCropBox = {
      x: Math.round(cropBox.x * scaleX),
      y: Math.round(cropBox.y * scaleY),
      width: Math.round(cropBox.width * scaleX),
      height: Math.round(cropBox.height * scaleY)
    };

    const croppedLogoDataUrl = await LogoEngine.cropLogo(imageObj, naturalCropBox);
    onLogoSelected(croppedLogoDataUrl);
    onCloseCropModal();
  };

  // Direct Logo File Upload & Drag and Drop Handlers
  const handleLogoFile = (file) => {
    if (!file) return;
    const validation = validateImageFile(file);
    if (!validation.valid) {
      alert(validation.error);
      return;
    }
    const reader = new FileReader();
    reader.onload = (evt) => {
      onLogoFileUploaded(evt.target.result);
    };
    reader.readAsDataURL(file);
  };

  // Profile Photo File Upload & Drag and Drop Handlers
  const handleProfileFile = (file) => {
    if (!file) return;
    const validation = validateImageFile(file);
    if (!validation.valid) {
      alert(validation.error);
      return;
    }
    const reader = new FileReader();
    reader.onload = (evt) => {
      onProfilePicSelected(evt.target.result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <>
      <div className="card-section" style={{ margin: '16px 0', padding: '18px 20px' }}>
        <div className="section-title" style={{ marginBottom: '16px' }}>
          <span>Brand Identity (Logo & Optional Profile Photo)</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>

          {/* 1. LOGO UPLOAD & CROP CARD */}
          <div
            style={{
              border: `2px dashed ${logoDragOver ? '#2563eb' : '#cbd5e1'}`,
              borderRadius: '10px',
              padding: '14px',
              backgroundColor: logoDragOver ? '#eff6ff' : '#f8fafc',
              transition: 'all 0.2s',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px'
            }}
            onDragOver={(e) => { e.preventDefault(); setLogoDragOver(true); }}
            onDragLeave={() => setLogoDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setLogoDragOver(false);
              const file = e.dataTransfer.files[0];
              handleLogoFile(file);
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '13px', fontWeight: '700', color: '#1e293b' }}>
                🏷️ Brand Logo
              </span>
              {logoUrl && (
                <button
                  className="btn btn-secondary"
                  style={{ padding: '2px 8px', fontSize: '11px', color: '#dc2626' }}
                  onClick={() => onLogoSelected(null)}
                >
                  Remove
                </button>
              )}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              {logoUrl ? (
                <div style={{ width: '56px', height: '56px', background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '4px' }}>
                  <img src={logoUrl} alt="Logo" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
                </div>
              ) : (
                <div style={{ width: '56px', height: '56px', background: '#e2e8f0', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px' }}>
                  🏷️
                </div>
              )}

              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '12px', fontWeight: '600' }}>
                  {logoUrl ? 'Logo Active' : 'Drag & drop or upload logo'}
                </div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                  PNG, SVG, JPG, WebP
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '8px', marginTop: '4px' }}>
              <button
                className="btn btn-secondary"
                style={{ flex: 1, padding: '6px 10px', fontSize: '12px' }}
                onClick={() => logoInputRef.current?.click()}
              >
                📁 Upload Logo
              </button>
              <input
                ref={logoInputRef}
                type="file"
                accept="image/png, image/jpeg, image/jpg, image/webp, image/svg+xml"
                style={{ display: 'none' }}
                onChange={(e) => handleLogoFile(e.target.files[0])}
              />

              <button
                className="btn btn-secondary"
                style={{ flex: 1, padding: '6px 10px', fontSize: '12px' }}
                onClick={onOpenCropModal}
              >
                ✂️ Crop from Poster
              </button>
            </div>
          </div>

          {/* 2. PROFILE PHOTO UPLOAD CARD (OPTIONAL) */}
          <div
            style={{
              border: `2px dashed ${profileDragOver ? '#2563eb' : '#cbd5e1'}`,
              borderRadius: '10px',
              padding: '14px',
              backgroundColor: profileDragOver ? '#eff6ff' : '#f8fafc',
              transition: 'all 0.2s',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px'
            }}
            onDragOver={(e) => { e.preventDefault(); setProfileDragOver(true); }}
            onDragLeave={() => setProfileDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setProfileDragOver(false);
              const file = e.dataTransfer.files[0];
              handleProfileFile(file);
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: '13px', fontWeight: '700', color: '#1e293b' }}>
                👤 Profile Photo (Optional)
              </span>
              {profilePicUrl && (
                <button
                  className="btn btn-secondary"
                  style={{ padding: '2px 8px', fontSize: '11px', color: '#dc2626' }}
                  onClick={onRemoveProfilePic}
                >
                  Remove
                </button>
              )}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              {profilePicUrl ? (
                <div style={{
                  width: '56px',
                  height: '56px',
                  borderRadius: profileShape === 'circle' ? '50%' : profileShape === 'rounded' ? '12px' : '0',
                  clipPath: profileShape === 'hexagon' ? 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' : 'none',
                  overflow: 'hidden',
                  border: '2px solid #2563eb',
                  background: '#fff'
                }}>
                  <img src={profilePicUrl} alt="Profile" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>
              ) : (
                <div style={{ width: '56px', height: '56px', background: '#e2e8f0', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '24px' }}>
                  👤
                </div>
              )}

              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '12px', fontWeight: '600' }}>
                  {profilePicUrl ? 'Profile Photo Added' : 'Drag & drop profile picture'}
                </div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                  Adds personal authenticity to footer
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginTop: '4px' }}>
              <button
                className="btn btn-secondary"
                style={{ flex: 1, padding: '6px 10px', fontSize: '12px' }}
                onClick={() => profileInputRef.current?.click()}
              >
                📷 Upload Photo
              </button>
              <input
                ref={profileInputRef}
                type="file"
                accept="image/png, image/jpeg, image/jpg, image/webp"
                style={{ display: 'none' }}
                onChange={(e) => handleProfileFile(e.target.files[0])}
              />

              {profilePicUrl && (
                <div style={{ display: 'flex', gap: '4px' }}>
                  {['circle', 'rounded', 'hexagon'].map((shape) => (
                    <button
                      key={shape}
                      className={`btn ${profileShape === shape ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ padding: '4px 8px', fontSize: '11px', textTransform: 'capitalize' }}
                      onClick={() => onProfileShapeChanged(shape)}
                    >
                      {shape === 'circle' ? '⭕' : shape === 'rounded' ? '▢' : '⬡'}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* MANUAL CROP MODAL (Opened via "Crop from Poster") */}
      {isOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '640px' }}>
            <div className="modal-header">
              <h3>Manual Logo Crop from Poster</h3>
              <button className="btn btn-secondary" style={{ padding: '4px 8px' }} onClick={onCloseCropModal}>
                ✕
              </button>
            </div>

            <div className="modal-body">
              <p style={{ fontSize: '13px', color: 'var(--text-muted)', textAlign: 'center', margin: 0 }}>
                Click & drag (or touch & drag) a box around your logo on the poster.
              </p>

              {/* Quick Preset Buttons */}
              <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'center' }}>
                <button className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '11px' }} onClick={() => applyPresetRegion('bottom-left')}>
                  Bottom-Left
                </button>
                <button className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '11px' }} onClick={() => applyPresetRegion('bottom-center')}>
                  Bottom-Center
                </button>
                <button className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '11px' }} onClick={() => applyPresetRegion('bottom-right')}>
                  Bottom-Right
                </button>
                <button className="btn btn-secondary" style={{ padding: '4px 10px', fontSize: '11px' }} onClick={() => applyPresetRegion('top-left')}>
                  Top-Left
                </button>
              </div>

              {/* Canvas with Mouse & Touch Event Listeners */}
              <div className="crop-canvas-wrapper" style={{ touchAction: 'none' }}>
                <canvas
                  ref={canvasRef}
                  style={{ cursor: 'crosshair', display: 'block', touchAction: 'none' }}
                  onMouseDown={handlePointerDown}
                  onMouseMove={handlePointerMove}
                  onMouseUp={handlePointerUp}
                  onTouchStart={handlePointerDown}
                  onTouchMove={handlePointerMove}
                  onTouchEnd={handlePointerUp}
                />
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={onCloseCropModal}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleApplyCrop}>
                Confirm Crop & Extract Colors
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
