import React, { useRef } from 'react';
import FooterCard from './FooterCard';
import DownloadButton from './DownloadButton';
import { validateImageFile } from '../utils/validation';

export default function FooterGallery({
  footers,
  selectedFooter,
  onSelectFooter,
  onRegenerate,
  onUploadCustomTemplate,
  poster
}) {
  const templateInputRef = useRef(null);

  if (!footers || footers.length === 0) return null;

  const handleTemplateUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const validation = validateImageFile(file);
    if (!validation.valid) {
      alert(validation.error);
      return;
    }
    const reader = new FileReader();
    reader.onload = (evt) => {
      onUploadCustomTemplate({
        id: `custom-tmpl-${Date.now()}`,
        name: file.name.replace(/\.[^/.]+$/, '').slice(0, 16),
        category: 'Custom Upload',
        customImageUrl: evt.target.result,
        supportedColors: ['primary', 'secondary', 'accent'],
        logoConfig: { x: 45, y: 45, width: 180, height: 90, alignment: 'left' }
      });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="card-section gallery-section">
      <div className="section-title">
        <span>Generated Footer Designs ({footers.length} Options)</span>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            type="button"
            className="btn btn-secondary"
            style={{ padding: '5px 12px', fontSize: '12px' }}
            onClick={() => templateInputRef.current?.click()}
          >
            <span>📤</span> Upload Custom Template Image
          </button>
          <input
            ref={templateInputRef}
            type="file"
            accept="image/png, image/jpeg, image/jpg, image/webp, image/svg+xml"
            style={{ display: 'none' }}
            onChange={handleTemplateUpload}
          />
        </div>
      </div>

      {/* Grid of Footer Thumbnails */}
      <div className="footer-gallery-grid">
        {footers.map((footer) => (
          <FooterCard
            key={footer.id}
            footer={footer}
            isSelected={selectedFooter?.id === footer.id}
            onSelect={onSelectFooter}
          />
        ))}
      </div>

      {/* Action Bar: Regenerate & Download */}
      <div className="gallery-action-bar">
        <button className="btn btn-secondary" onClick={onRegenerate}>
          <span>✨</span> Regenerate Designs
        </button>

        <DownloadButton
          poster={poster}
          selectedFooter={selectedFooter}
        />
      </div>
    </div>
  );
}
