import React, { useRef, useState } from 'react';
import { validateImageFile } from '../utils/validation';

export default function PosterUpload({ onPosterSelected, currentPoster, onReplacePoster }) {
  const fileInputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleFile = (file) => {
    if (!file) return;
    setErrorMsg('');
    const validation = validateImageFile(file);
    if (!validation.valid) {
      setErrorMsg(validation.error);
      return;
    }
    onPosterSelected(file);
  };

  const handleInputChange = (e) => {
    const file = e.target.files[0];
    handleFile(file);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    handleFile(file);
  };

  return (
    <div className="card-section upload-section">
      <div className="section-title">
        <span>Upload Your Poster</span>
        {currentPoster && (
          <span style={{ fontSize: '12px', fontWeight: 'normal', color: 'var(--text-muted)' }}>
            Dimensions: {currentPoster.width} × {currentPoster.height} px
          </span>
        )}
      </div>

      {errorMsg && <div className="error-banner">{errorMsg}</div>}

      {!currentPoster ? (
        <div
          className={`upload-area ${dragOver ? 'drag-over' : ''}`}
          onClick={() => fileInputRef.current?.click()}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="upload-icon">📤</div>
          <div className="upload-instruction">Click to browse or drop your poster here</div>
          <div className="upload-hint">Supports PNG, JPG, JPEG, and WebP (up to 15 MB)</div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png, image/jpeg, image/jpg, image/webp"
            style={{ display: 'none' }}
            onChange={handleInputChange}
          />
        </div>
      ) : (
        <div className="file-info-bar">
          <div className="file-name">
            <span>🖼️</span>
            <span>{currentPoster.name}</span>
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              className="btn btn-secondary"
              onClick={() => {
                fileInputRef.current?.click();
              }}
            >
              Replace Poster
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png, image/jpeg, image/jpg, image/webp"
              style={{ display: 'none' }}
              onChange={handleInputChange}
            />
          </div>
        </div>
      )}
    </div>
  );
}

