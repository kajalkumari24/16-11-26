import React from 'react';

export default function ColorPalette({ palette, onRegeneratePalette }) {
  if (!palette) return null;

  const colorItems = [
    { label: 'Primary', value: palette.primary },
    { label: 'Secondary', value: palette.secondary },
    { label: 'Accent', value: palette.accent },
    { label: 'Text', value: palette.text }
  ];

  return (
    <div className="card-section palette-section" style={{ padding: '16px 20px', margin: '14px 0' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
        <div style={{ fontSize: '14px', fontWeight: 'bold' }}>Extracted Logo Color Palette</div>
        {onRegeneratePalette && (
          <button
            className="btn btn-secondary"
            style={{ padding: '4px 10px', fontSize: '12px' }}
            onClick={onRegeneratePalette}
          >
            🔄 Regenerate Palette
          </button>
        )}
      </div>

      <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
        {colorItems.map((item) => (
          <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div
              style={{
                width: '28px',
                height: '28px',
                borderRadius: '6px',
                backgroundColor: item.value,
                border: '1px solid rgba(0,0,0,0.15)',
                boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
              }}
            />
            <div>
              <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>{item.label}</div>
              <div style={{ fontSize: '12px', fontWeight: 'bold', fontFamily: 'monospace' }}>
                {item.value}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

