import React from 'react';

export default function FooterCard({ footer, isSelected, onSelect }) {
  return (
    <div
      className={`footer-card ${isSelected ? 'selected' : ''}`}
      onClick={() => onSelect(footer)}
    >
      {isSelected && <span className="footer-card-badge">Active</span>}

      {/* Mini SVG Preview */}
      <div
        className="footer-card-preview"
        dangerouslySetInnerHTML={{ __html: footer.compiledSvg }}
      />

      {/* Info & Category */}
      <div className="footer-card-info">
        <span className="footer-card-name">{footer.name}</span>
        <span className="footer-card-category">{footer.category}</span>
      </div>
    </div>
  );
}

