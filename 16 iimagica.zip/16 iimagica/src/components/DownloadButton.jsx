import React, { useState } from 'react';
import { ExportEngine } from '../engines/exportEngine';

export default function DownloadButton({ poster, selectedFooter }) {
  const [isExporting, setIsExporting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleDownload = async () => {
    if (!poster) return;
    if (!selectedFooter) {
      setErrorMsg('Please select a footer design before downloading.');
      return;
    }

    setErrorMsg('');
    setIsExporting(true);

    try {
      const cleanPosterName = poster.name ? poster.name.replace(/\.[^/.]+$/, '') : 'poster';
      const filename = `${cleanPosterName}-with-${selectedFooter.id}.png`;

      await ExportEngine.exportPoster({
        posterUrl: poster.url,
        posterWidth: poster.width,
        posterHeight: poster.height,
        selectedFooter,
        filename
      });
    } catch (err) {
      console.error('Export error:', err);
      setErrorMsg('Failed to export poster: ' + (err.message || 'Unknown error'));
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div style={{ display: 'inline-flex', flexDirection: 'column', alignItems: 'center' }}>
      <button
        className="btn btn-primary"
        onClick={handleDownload}
        disabled={isExporting || !poster || !selectedFooter}
      >
        {isExporting ? (
          <>
            <span className="spinner"></span>
            <span>Exporting Full-Res PNG...</span>
          </>
        ) : (
          <>
            <span>⬇️</span>
            <span>Download Poster (PNG)</span>
          </>
        )}
      </button>

      {errorMsg && (
        <span style={{ fontSize: '12px', color: '#dc2626', marginTop: '6px' }}>
          {errorMsg}
        </span>
      )}
    </div>
  );
}
