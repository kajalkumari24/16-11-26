/**
 * Template Service
 * Loads SVG templates, injects colors, logo, optional profile photo,
 * and dynamic brand details (Name, Company, Contacts & Custom Badges).
 */

import { FOOTER_TEMPLATES } from '../data/templates.js';

const templateCache = new Map();

/**
 * Fetches the raw SVG markup for a given template
 * @param {string} filePath
 * @returns {Promise<string>}
 */
export async function loadSvgMarkup(filePath) {
  if (templateCache.has(filePath)) {
    return templateCache.get(filePath);
  }

  try {
    const response = await fetch(filePath);
    if (!response.ok) {
      throw new Error(`Failed to load template from ${filePath}: ${response.statusText}`);
    }
    const svgText = await response.text();
    templateCache.set(filePath, svgText);
    return svgText;
  } catch (err) {
    console.error('Error fetching template SVG:', err);
    throw err;
  }
}

/**
 * Injects color variables, logo, optional profile photo, and brand details into the SVG
 * @param {string} svgMarkup
 * @param {{ primary: string, secondary: string, accent: string, text: string }} colors
 * @param {string|null} logoUrl
 * @param {number} width
 * @param {number} height
 * @param {Object|null} logoConfig
 * @param {string} logoAlignment
 * @param {string|null} profilePicUrl
 * @param {string} profileShape
 * @param {Object|null} brandDetails
 * @returns {string} compiled SVG markup
 */
export function compileSvgTemplate(
  svgMarkup,
  colors,
  logoUrl = null,
  width = 1000,
  height = 180,
  logoConfig = null,
  logoAlignment = 'left',
  profilePicUrl = null,
  profileShape = 'circle',
  brandDetails = null
) {
  let compiled = svgMarkup;

  // Replace CSS color variables with concrete values for maximum cross-browser canvas compatibility
  compiled = compiled.replace(/var\(--primary-color[^)]*\)/g, colors.primary);
  compiled = compiled.replace(/var\(--secondary-color[^)]*\)/g, colors.secondary);
  compiled = compiled.replace(/var\(--accent-color[^)]*\)/g, colors.accent);
  compiled = compiled.replace(/var\(--text-color[^)]*\)/g, colors.text || '#FFFFFF');

  // Extract SVG viewBox dimensions to adaptively position logo, profile photo, and brand text
  const vbMatch = svgMarkup.match(/viewBox=["']\s*([0-9.-]+)\s+([0-9.-]+)\s+([0-9.-]+)\s+([0-9.-]+)\s*["']/);
  const vbWidth = vbMatch ? parseFloat(vbMatch[3]) : 1000;
  const vbHeight = vbMatch ? parseFloat(vbMatch[4]) : 180;

  // Compute configurable logo position
  const cfg = logoConfig || { x: 45, y: Math.round(vbHeight * 0.25), width: 180, height: Math.min(96, Math.round(vbHeight * 0.5)) };
  let posX = cfg.x;
  const posY = cfg.y;
  const slotW = cfg.width;
  const slotH = cfg.height;

  if (logoAlignment === 'center') {
    posX = Math.round((vbWidth - slotW) / 2);
  } else if (logoAlignment === 'right') {
    posX = Math.round(vbWidth - slotW - cfg.x);
  }

  // Ensure root SVG has preserveAspectRatio="none" so it fills the dock seamlessly
  if (!compiled.includes('preserveAspectRatio=')) {
    compiled = compiled.replace('<svg ', '<svg preserveAspectRatio="none" width="100%" height="100%" ');
  }

  // 1. Insert or position Logo
  if (logoUrl) {
    const logoElement = `
      <g class="logo-slot" transform="translate(${posX}, ${posY})">
        <image href="${logoUrl}" width="${slotW}" height="${slotH}" preserveAspectRatio="xMidYMid meet" />
      </g>
    `;
    compiled = compiled.replace(
      /<g class="logo-slot"[^>]*>[\s\S]*?<\/g>/,
      logoElement
    );
  } else {
    compiled = compiled.replace(
      /<g class="logo-slot"[^>]*transform="[^"]*"[^>]*>/,
      `<g class="logo-slot" transform="translate(${posX}, ${posY})">`
    );
  }

  // 2. Insert Profile Photo if provided
  if (profilePicUrl) {
    const clipId = `profile-clip-${Math.random().toString(36).substr(2, 9)}`;
    const size = Math.min(96, Math.max(64, Math.round(slotH * 1.05)));
    const px = logoAlignment === 'right' ? cfg.x : Math.round(vbWidth - size - cfg.x);
    const py = cfg.y;
    const cx = px + size / 2;
    const cy = py + size / 2;
    const r = size / 2;

    let clipDef = `<circle cx="${cx}" cy="${cy}" r="${r}" />`;
    let borderElement = `<circle cx="${cx}" cy="${cy}" r="${r + 3}" fill="${colors.accent || '#F59E0B'}" />`;

    if (profileShape === 'rounded') {
      clipDef = `<rect x="${px}" y="${py}" width="${size}" height="${size}" rx="18" />`;
      borderElement = `<rect x="${px - 3}" y="${py - 3}" width="${size + 6}" height="${size + 6}" rx="21" fill="${colors.accent || '#F59E0B'}" />`;
    } else if (profileShape === 'hexagon') {
      const p1 = `${cx},${py}`;
      const p2 = `${px + size},${py + size * 0.25}`;
      const p3 = `${px + size},${py + size * 0.75}`;
      const p4 = `${cx},${py + size}`;
      const p5 = `${px},${py + size * 0.75}`;
      const p6 = `${px},${py + size * 0.25}`;
      clipDef = `<polygon points="${p1} ${p2} ${p3} ${p4} ${p5} ${p6}" />`;
      borderElement = `<polygon points="${p1} ${p2} ${p3} ${p4} ${p5} ${p6}" stroke="${colors.accent || '#F59E0B'}" stroke-width="4" fill="none" />`;
    }

    const profileMarkup = `
      <defs>
        <clipPath id="${clipId}">
          ${clipDef}
        </clipPath>
      </defs>
      <g class="profile-photo-slot">
        ${borderElement}
        <image href="${profilePicUrl}" x="${px}" y="${py}" width="${size}" height="${size}" clip-path="url(#${clipId})" preserveAspectRatio="xMidYMid slice" />
      </g>
    `;

    compiled = compiled.replace('</svg>', `${profileMarkup}</svg>`);
  }

  // 3. Render Brand Details Typography & Custom Badges
  if (brandDetails) {
    const textColor = colors.text || '#FFFFFF';
    const accentColor = colors.accent || '#F59E0B';
    const textStartX = logoAlignment === 'left' ? (logoUrl ? (cfg.x + slotW + 24) : (cfg.x + 10)) : 50;
    const row1Y = cfg.y + (customFields.length > 0 ? Math.round(slotH * 0.28) : Math.round(slotH * 0.42));
    const row2Y = cfg.y + (customFields.length > 0 ? Math.round(slotH * 0.66) : Math.round(slotH * 0.82));
    const badgeY = cfg.y + Math.round(slotH * 0.96);

    // Build contacts string
    const contactsList = [
      brandDetails.phone ? `📞 ${brandDetails.phone}` : '',
      brandDetails.email ? `✉️ ${brandDetails.email}` : '',
      brandDetails.website ? `🌐 ${brandDetails.website}` : ''
    ].filter(Boolean);
    const contactsText = contactsList.join('   |   ');

    // Build custom dynamic fields badges
    let customBadgesSvg = '';
    const customFields = (brandDetails.customFields || []).filter((f) => f.label && f.value);
    if (customFields.length > 0) {
      let badgeX = textStartX;
      customBadgesSvg = customFields
        .slice(0, 4) // display up to 4 custom badges neatly
        .map((f) => {
          const badgeText = `${f.label}: ${f.value}`;
          const badgeWidth = Math.min(220, badgeText.length * 8.5 + 16);
          const currentX = badgeX;
          badgeX += badgeWidth + 10;
          return `
            <g transform="translate(${currentX}, ${badgeY})">
              <rect width="${badgeWidth}" height="24" rx="5" fill="${accentColor}" opacity="0.95" />
              <text x="${badgeWidth / 2}" y="16" fill="#0F172A" font-size="11" font-weight="bold" font-family="system-ui, -apple-system, sans-serif" text-anchor="middle">
                ${escapeXml(badgeText)}
              </text>
            </g>
          `;
        })
        .join('');
    }

    const brandTextMarkup = `
      <g class="brand-text-slot" style="user-select: none;">
        <!-- Row 1: Name and Company -->
        ${brandDetails.name ? `
          <text x="${textStartX}" y="${row1Y}" fill="${textColor}" font-size="22" font-weight="800" font-family="system-ui, -apple-system, sans-serif" letter-spacing="-0.3">
            ${escapeXml(brandDetails.name)}
          </text>
        ` : ''}

        ${brandDetails.company ? `
          <text x="${textStartX + (brandDetails.name ? brandDetails.name.length * 13 + 20 : 0)}" y="${row1Y}" fill="${accentColor}" font-size="16" font-weight="700" font-family="system-ui, -apple-system, sans-serif">
            ${brandDetails.name ? '•  ' : ''}${escapeXml(brandDetails.company)}
          </text>
        ` : ''}

        <!-- Row 2: Contacts -->
        ${contactsText ? `
          <text x="${textStartX}" y="${row2Y}" fill="${textColor}" font-size="14" font-weight="500" font-family="system-ui, -apple-system, sans-serif" opacity="0.92">
            ${escapeXml(contactsText)}
          </text>
        ` : ''}

        <!-- Row 3: Custom Badges -->
        ${customBadgesSvg}
      </g>
    `;

    compiled = compiled.replace('</svg>', `${brandTextMarkup}</svg>`);
  }

  return compiled;
}

function escapeXml(unsafe) {
  return String(unsafe)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export function getAllTemplates() {
  return FOOTER_TEMPLATES;
}
