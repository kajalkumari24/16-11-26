/**
 * Image Service
 * Handles file reading, dimensions extraction, and object preparation
 */

import { loadImage, createSafeObjectUrl } from '../utils/imageUtils.js';
import { validateImageFile } from '../utils/validation.js';

export async function processUploadedPoster(file) {
  const validation = validateImageFile(file);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const url = createSafeObjectUrl(file);
  const img = await loadImage(url);

  return {
    file,
    url,
    name: file.name,
    width: img.naturalWidth || img.width,
    height: img.naturalHeight || img.height,
    aspectRatio: (img.naturalWidth / img.naturalHeight).toFixed(3)
  };
}

