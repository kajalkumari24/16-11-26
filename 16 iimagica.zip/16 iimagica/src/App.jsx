import React, { useState, useEffect, useCallback } from 'react';
import PosterUpload from './components/PosterUpload';
import PosterPreview from './components/PosterPreview';
import LogoSelector from './components/LogoSelector';
import BrandDetails from './components/BrandDetails';
import ColorPalette from './components/ColorPalette';
import FooterGallery from './components/FooterGallery';
import { processUploadedPoster } from './services/imageService';
import { ColorEngine } from './engines/colorEngine';
import { FooterEngine } from './engines/footerEngine';
import { revokeSafeObjectUrl } from './utils/imageUtils';

export default function App() {
  // Core MVP React States (Section 11)
  const [poster, setPoster] = useState(null);
  const [logo, setLogo] = useState(null);
  const [profilePic, setProfilePic] = useState(null);
  const [profileShape, setProfileShape] = useState('circle');
  const [palette, setPalette] = useState(null);
  const [footers, setFooters] = useState([]);
  const [selectedFooter, setSelectedFooter] = useState(null);
  const [logoAlignment, setLogoAlignment] = useState('left');

  // Dynamic Brand Details & Custom Dynamic Badges
  const [brandDetails, setBrandDetails] = useState({
    name: 'Rajesh Sharma',
    company: 'IIMAGICA Tech Ventures',
    phone: '+91 98765 43210',
    email: 'connect@iimagica.com',
    website: 'www.iimagica.com',
    customFields: [
      { id: 'cf-1', label: 'Govt Reg', value: 'REG-2026-8849' },
      { id: 'cf-2', label: 'ISO Standard', value: 'ISO 9001:2015' }
    ]
  });

  // User-uploaded custom templates
  const [customTemplates, setCustomTemplates] = useState([]);

  // UI state
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // 1. Safe Poster Upload & Replacement
  const handlePosterSelected = async (file) => {
    if (!file) return;

    try {
      setErrorMessage('');
      setLoadingStatus('Reading poster image and analyzing dimensions...');

      if (poster?.url) {
        revokeSafeObjectUrl(poster.url);
      }

      setLogo(null);
      setProfilePic(null);
      setPalette(null);
      setFooters([]);
      setSelectedFooter(null);

      const processed = await processUploadedPoster(file);
      setPoster(processed);

      setLoadingStatus('Extracting initial colors from poster...');
      const initialPalette = await ColorEngine.extractPalette(processed.url, processed.url);
      setPalette(initialPalette);
    } catch (err) {
      console.error('Poster load error:', err);
      setErrorMessage(err.message || 'Failed to load poster image. Please verify format.');
    } finally {
      setLoadingStatus('');
    }
  };

  const handleReplacePoster = () => {
    if (poster?.url) {
      revokeSafeObjectUrl(poster.url);
    }
    setPoster(null);
    setLogo(null);
    setProfilePic(null);
    setPalette(null);
    setFooters([]);
    setSelectedFooter(null);
    setErrorMessage('');
    setLoadingStatus('');
  };

  // 2A. Handle Logo Selected via Crop
  const handleLogoSelected = async (croppedLogoDataUrl) => {
    if (!croppedLogoDataUrl) {
      setLogo(null);
      return;
    }

    setLogo(croppedLogoDataUrl);
    setIsCropModalOpen(false);

    try {
      setLoadingStatus('Extracting colors from cropped logo...');
      const extractedPalette = await ColorEngine.extractPalette(
        croppedLogoDataUrl,
        poster ? poster.url : null
      );
      setPalette(extractedPalette);
    } catch (err) {
      console.warn('Color extraction warning:', err);
    } finally {
      setLoadingStatus('');
    }
  };

  // 2B. Handle Logo Directly Uploaded / Dropped
  const handleLogoFileUploaded = async (dataUrl) => {
    if (!dataUrl) return;
    setLogo(dataUrl);

    try {
      setLoadingStatus('Extracting colors from uploaded logo (filtering transparency)...');
      const extractedPalette = await ColorEngine.extractPalette(
        dataUrl,
        poster ? poster.url : null
      );
      setPalette(extractedPalette);
    } catch (err) {
      console.warn('Color extraction warning:', err);
    } finally {
      setLoadingStatus('');
    }
  };

  // 2C. Handle Profile Photo Uploaded / Dropped
  const handleProfilePicSelected = (dataUrl) => {
    setProfilePic(dataUrl);
  };

  const handleRemoveProfilePic = () => {
    setProfilePic(null);
  };

  // 2D. Handle Custom Template Upload
  const handleUploadCustomTemplate = (newTemplate) => {
    setCustomTemplates((prev) => [newTemplate, ...prev]);
  };

  // 3. Generate Footer Designs with Brand Details
  const generateFooters = useCallback(async () => {
    if (!poster || !palette) return;

    try {
      setLoadingStatus('Generating footer designs with your brand details...');
      const generated = await FooterEngine.generateFooters({
        logo,
        colorPalette: palette,
        posterWidth: poster.width,
        posterHeight: poster.height,
        logoAlignment,
        profilePicUrl: profilePic,
        profileShape,
        brandDetails,
        customTemplates
      });

      setFooters(generated);

      if (generated.length > 0) {
        setSelectedFooter((prev) => {
          if (!prev) return generated[0];
          const match = generated.find((f) => f.id === prev.id);
          return match || generated[0];
        });
      }
    } catch (err) {
      console.error('Footer generation error:', err);
      setErrorMessage('Failed to generate footer designs. Please try regenerating.');
    } finally {
      setLoadingStatus('');
    }
  }, [poster, logo, palette, logoAlignment, profilePic, profileShape, brandDetails, customTemplates]);

  useEffect(() => {
    if (poster && palette) {
      generateFooters();
    }
  }, [poster, logo, palette, logoAlignment, profilePic, profileShape, brandDetails, customTemplates, generateFooters]);

  // 4. Regenerate Palette with variation
  const handleRegeneratePalette = async () => {
    if (!poster) return;
    try {
      setLoadingStatus('Refreshing color palette...');
      const source = logo || poster.url;
      const refreshed = await ColorEngine.extractPalette(source, poster.url);
      setPalette(refreshed);
    } catch (err) {
      console.warn('Failed to regenerate palette:', err);
    } finally {
      setLoadingStatus('');
    }
  };

  return (
    <div className="app-container">
      {/* Website Header */}
      <header className="app-header">
        <h1 className="app-title">SMART FOOTER GENERATOR</h1>
        <p className="app-subtitle">
          Upload your poster, logo & profile photo. Customize brand details and generate matching footers instantly.
        </p>
      </header>

      {/* Global Error Banner */}
      {errorMessage && (
        <div className="error-banner" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>⚠️ {errorMessage}</span>
          <button
            onClick={() => setErrorMessage('')}
            style={{ background: 'transparent', border: 'none', color: '#b91c1c', cursor: 'pointer', fontWeight: 'bold' }}
          >
            ✕
          </button>
        </div>
      )}

      {/* Visible Loading Indicator */}
      {loadingStatus && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 16px', background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '8px', color: '#1e40af', fontSize: '13px', fontWeight: '500' }}>
          <span className="spinner" style={{ borderTopColor: '#2563eb', borderColor: 'rgba(37, 99, 235, 0.2)' }}></span>
          <span>{loadingStatus}</span>
        </div>
      )}

      {/* Section A: Upload Area */}
      <PosterUpload
        onPosterSelected={handlePosterSelected}
        currentPoster={poster}
        onReplacePoster={handleReplacePoster}
      />

      {/* Brand Identity: Upload Logo, Crop Logo & Upload Profile Photo (Drag & Drop Supported) */}
      {poster && (
        <LogoSelector
          poster={poster}
          logoUrl={logo}
          onLogoSelected={handleLogoSelected}
          onLogoFileUploaded={handleLogoFileUploaded}
          profilePicUrl={profilePic}
          onProfilePicSelected={handleProfilePicSelected}
          onRemoveProfilePic={handleRemoveProfilePic}
          profileShape={profileShape}
          onProfileShapeChanged={(shape) => setProfileShape(shape)}
          isOpen={isCropModalOpen}
          onOpenCropModal={() => setIsCropModalOpen(true)}
          onCloseCropModal={() => setIsCropModalOpen(false)}
        />
      )}

      {/* Brand Details & "+ Add More Brand Detail" Component */}
      {poster && (
        <BrandDetails
          brandDetails={brandDetails}
          onChangeBrandDetails={setBrandDetails}
        />
      )}

      {/* Configurable Logo Positioning Toolbar */}
      {poster && (
        <div className="card-section" style={{ padding: '12px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '10px' }}>
          <div style={{ fontSize: '13px', fontWeight: '600', color: '#334155' }}>
            <span>Logo Position in Footer:</span>
          </div>
          <div style={{ display: 'flex', gap: '6px' }}>
            {['left', 'center', 'right'].map((align) => (
              <button
                key={align}
                className={`btn ${logoAlignment === align ? 'btn-primary' : 'btn-secondary'}`}
                style={{ padding: '4px 14px', fontSize: '12px', textTransform: 'capitalize' }}
                onClick={() => setLogoAlignment(align)}
              >
                {align}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Color Palette Display */}
      {palette && (
        <ColorPalette
          palette={palette}
          onRegeneratePalette={handleRegeneratePalette}
        />
      )}

      {/* Section B: Poster Live Preview with Canvas Drag & Drop */}
      <PosterPreview
        poster={poster}
        selectedFooter={selectedFooter}
        onPosterDropped={handlePosterSelected}
      />

      {/* Section C: Footer Designs Gallery & Actions */}
      {footers.length > 0 && (
        <FooterGallery
          footers={footers}
          selectedFooter={selectedFooter}
          onSelectFooter={(f) => setSelectedFooter(f)}
          onRegenerate={generateFooters}
          onUploadCustomTemplate={handleUploadCustomTemplate}
          poster={poster}
        />
      )}
    </div>
  );
}
