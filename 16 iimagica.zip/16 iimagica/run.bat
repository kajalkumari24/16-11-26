@echo off
title Smart Poster Footer Generator
cd /d "%~dp0"
echo ========================================================
echo Starting Smart Poster Footer Generator (Vite + React)...
echo ========================================================
start "" "http://localhost:5500"
npm run dev
pause
