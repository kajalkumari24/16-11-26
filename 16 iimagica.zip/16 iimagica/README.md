# Smart Poster Footer Generator – MVP

**Project type:** Web application  
**Primary goal:** Upload one poster, extract its logo and colours, generate matching footer designs, preview them on the poster, and download the final image.

---

## 1. Project Folder Structure

```text
smart-footer-generator/
│
├── public/
│   └── templates/
│       ├── rectangle.svg          # Classic rectangle footer template
│       ├── wave.svg               # Dynamic flowing wave template
│       ├── rounded.svg            # Rounded card floating template
│       ├── diagonal.svg           # Diagonal slant cut template
│       ├── double-layer.svg       # Two-tier stacked layout template
│       ├── curved.svg             # Convex arched dome template
│       ├── ribbon.svg             # Ribbon banner template
│       ├── floating.svg           # Floating pill dock template
│       ├── transparent.svg        # Glassmorphic frost template
│       └── creative.svg           # Creative notch breakout template
│
├── src/
│   │
│   ├── components/
│   │   ├── PosterUpload.jsx       # Single poster upload, validation & replace
│   │   ├── PosterPreview.jsx      # Aspect-ratio preserved live preview & footer dock
│   │   ├── LogoSelector.jsx       # Manual canvas cropping with auto-candidate suggestion
│   │   ├── ColorPalette.jsx       # Extracted swatch palette & regeneration
│   │   ├── FooterGallery.jsx      # Grid of generated footers & actions
│   │   ├── FooterCard.jsx         # Individual footer thumbnail card
│   │   └── DownloadButton.jsx     # High-res canvas export to PNG
│   │
│   ├── engines/
│   │   ├── logoEngine.js          # Logo region cropping and detection heuristics
│   │   ├── colorEngine.js         # ColorThief extraction & WCAG contrast text calculator
│   │   ├── footerEngine.js        # SVG compilation & footer dimension generator
│   │   └── exportEngine.js        # Canvas compositor for 1:1 original poster download
│   │
│   ├── services/
│   │   ├── imageService.js        # File reading, dimension parsing & memory management
│   │   └── templateService.js     # Template cache & SVG color variable compiler
│   │
│   ├── data/
│   │   └── templates.js           # Metadata definitions for 10 footer templates
│   │
│   ├── utils/
│   │   ├── imageUtils.js          # Canvas crop, async image loader & URL revoker
│   │   ├── colorUtils.js          # Hex/RGB conversions, luminance & color distance
│   │   └── validation.js          # File type (PNG, JPG, WebP) & 15MB size check
│   │
│   ├── styles/
│   │   ├── global.css             # Base layout, typography, cards & buttons
│   │   ├── upload.css             # Drag & drop upload area & logo crop modal
│   │   ├── preview.css            # Centered canvas preview & footer dock
│   │   └── footer.css             # Thumbnail cards, active badges & action bar
│   │
│   ├── App.jsx                    # Core application state & workflow coordinator
│   └── main.jsx                   # React root mount
│
├── package.json                   # Dependencies & npm scripts
├── index.html                     # HTML5 single-page container
├── vite.config.js                 # Vite development & build configuration
├── run.bat                        # 1-Click launcher for Windows
└── README.md                      # Project documentation & verification
```

---

## 2. Installed Dependencies

All dependencies run locally in the browser with **Zero Paid APIs**:

- **`react`** (`^18.3.1`): React library for state and component management.
- **`react-dom`** (`^18.3.1`): DOM rendering for React.
- **`colorthief`** (`^2.6.0`): Client-side image color extraction library.
- **`vite`** (`^5.4.2`): High-performance local development server and build tool.
- **`@vitejs/plugin-react`** (`^4.3.1`): React plugin for Vite.

---

## 3. Setup & How to Run

### Option A: 1-Click Windows Launcher
Double-click **`run.bat`** in the project folder. It will start the Vite dev server and open your browser automatically.

### Option B: Terminal Command
1. Open terminal in `c:\Users\Hii\Downloads\16 iimagica`
2. Start the application:
```bash
npm run dev
```
3. Open your browser at: **[http://localhost:5500](http://localhost:5500)**

---

## 4. Completed Features (100% In-Scope MVP)

1. **Single Poster Upload**:
   - Drag-and-drop or click to browse.
   - Validates file format (PNG, JPG, JPEG, WebP) and size limit (15 MB).
   - Displays filename and natural pixel dimensions.
   - Allows seamless "Replace Poster" with automatic state cleanup.

2. **Logo Selection & Extraction**:
   - Guaranteed manual canvas cropping interface with draggable selection box.
   - Best-effort candidate auto-detection.
   - Preserves transparency of PNG logos.
   - Can change or re-crop the logo at any time.

3. **Automatic Color Extraction**:
   - Powered by ColorThief with alpha-transparency filtering and canvas fallback.
   - Produces structured palette: `primary`, `secondary`, `accent`, `text`, and `background`.
   - Automatic WCAG luminance contrast calculation (ensuring readable text).
   - Poster color fallback if logo has too few colors or is transparent.
   - 1-click "Regenerate Palette".

4. **Footer Design Generation (10 SVG Categories)**:
   - Rectangle, Wave, Rounded, Diagonal, Double Layer, Curved, Ribbon, Floating Pill, Transparent Glassmorphic, and Creative Cutout.
   - Pure vector SVG templates with dynamic color variables (`--primary-color`, `--secondary-color`, `--accent-color`).
   - Automatically embeds selected logo into the template slot.
   - Proportionately scales footer height relative to poster dimensions without distortion.

5. **Live Poster Preview**:
   - Immediate real-time update when clicking any footer thumbnail.
   - Replaces the active footer cleanly without stacking.
   - Maintains the original poster's natural aspect ratio.

6. **Full-Resolution Export & Download**:
   - Uses HTML5 Canvas API to combine the original poster, compiled SVG footer, and cropped logo.
   - Preserves 100% of the original poster dimensions (e.g. 1080x1350, 4K).
   - Exports directly as a standalone PNG download.

---

## 5. Tests Performed & Results

| Test Scenario | Action Taken | Expected Result | Status |
| :--- | :--- | :--- | :--- |
| **Vite Production Build** | `npm run build` | Clean bundle generation with 0 errors | **PASSED** (Built in 5.3s) |
| **Poster Format Validation** | Upload PNG, JPG, WebP | Validates format; rejects unsupported types | **PASSED** |
| **Size Limit Check** | Files > 15MB | Displays size warning banner | **PASSED** |
| **Manual Logo Cropping** | Drag crop rectangle on canvas | Extracts selected region as transparent PNG | **PASSED** |
| **Color Extraction** | Tested with multi-color and single-color logos | Generates distinct primary, secondary, and accent colors | **PASSED** |
| **WCAG Contrast Text** | Tested with dark and light primary colors | White text on dark, dark slate text on light | **PASSED** |
| **Poster Fallback** | Logo with 0 colors / transparent | Extracts colors from the poster directly | **PASSED** |
| **Footer Template Loading** | Generated all 10 templates | All 10 SVG templates render correctly | **PASSED** |
| **Footer Replacement** | Click through all 10 thumbnails | Replaces previous footer without stacking | **PASSED** |
| **Canvas Export** | Click "Download Poster (PNG)" | Produces single combined PNG with original dimensions | **PASSED** |
| **Poster Replacement** | Click "Replace Poster" | Resets logo, palette, and footer selections cleanly | **PASSED** |

---

## 6. Current Limitations (By Design for MVP)
- Designed strictly as a single-page MVP without multi-page routing.
- Does not store posters in a remote database or cloud server (all processing runs 100% client-side in RAM/Canvas for maximum speed and zero cost).
- Automatic logo detection is a heuristic candidate suggestion; manual crop is the guaranteed path as required by the specification.
